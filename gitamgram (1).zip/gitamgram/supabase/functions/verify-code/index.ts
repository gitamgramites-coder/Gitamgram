// Verifies the code and marks the email as confirmed (creates the auth user if needed).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, apikey, content-type" };
const sha = async (s: string) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)))).map(b => b.toString(16).padStart(2, "0")).join("");
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const { email, code } = await req.json().catch(() => ({}));
  const e = String(email || "").trim().toLowerCase();
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: row } = await db.from("email_codes").select("*").eq("email", e).maybeSingle();
  if (!row || new Date(row.expires_at) < new Date()) return Response.json({ error: "That code has expired. Request a new one." }, { status: 400, headers: cors });
  if (row.attempts >= 5) return Response.json({ error: "Too many attempts. Request a new code." }, { status: 429, headers: cors });
  if (row.code_hash !== await sha(String(code) + e)) {
    await db.from("email_codes").update({ attempts: row.attempts + 1 }).eq("email", e);
    return Response.json({ error: "That code is incorrect." }, { status: 400, headers: cors });
  }
  await db.from("email_codes").delete().eq("email", e);
  return Response.json({ ok: true }, { headers: cors });
});
