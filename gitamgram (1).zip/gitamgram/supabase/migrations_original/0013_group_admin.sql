-- Group admins, admin-only messaging, restricted members and friend invites.
alter table groups add column if not exists admin_only boolean not null default false;   -- only admins may send messages/posts
alter table group_members drop constraint if exists group_members_role_check;
alter table group_members add constraint group_members_role_check check (role in ('owner','admin','member'));
create table if not exists group_bans (group_id uuid references groups on delete cascade, user_id uuid references profiles on delete cascade, banned_by uuid references profiles default auth.uid(), created_at timestamptz default now(), primary key (group_id, user_id));
alter table group_bans enable row level security;

create or replace function is_group_admin(g uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from group_members where group_id=g and user_id=auth.uid() and role in ('owner','admin')) $$;
create or replace function is_banned(g uuid, u uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from group_bans where group_id=g and user_id=u) $$;
create or replace function follows_user(a uuid, b uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from follows where follower_id=a and followee_id=b) $$;

drop policy if exists "groups owner edit" on groups;
create policy "groups edit" on groups for update using (owner_id=auth.uid() or is_group_admin(id)) with check (owner_id=auth.uid() or is_group_admin(id));

-- Members: join public groups (unless banned); admins add anyone; ANY member may add someone they follow (friend invite).
drop policy if exists "join public / owner adds" on group_members;
create policy "join or invite" on group_members for insert with check (
  not is_banned(group_id, user_id) and (
    (user_id=auth.uid() and role='member' and group_is_public(group_id) and is_verified())
    or (is_group_admin(group_id) and role='member')
    or (in_group(group_id) and role='member' and follows_user(auth.uid(), user_id))
    or (role='owner' and owns_group(group_id))));
-- Role changes (make/remove admin) by group admins.
create policy "assign admin" on group_members for update using (is_group_admin(group_id))
  with check (role in ('admin','member'));
drop policy if exists "leave or owner removes" on group_members;
create policy "leave or admin removes" on group_members for delete using (user_id=auth.uid() or (is_group_admin(group_id) and role <> 'owner'));

create policy "bans admin" on group_bans for all using (is_group_admin(group_id)) with check (is_group_admin(group_id));
create policy "bans self read" on group_bans for select using (user_id=auth.uid());

-- Admin-only mode and restricted members are enforced on sends.
drop policy if exists "gmsg send" on group_messages;
create policy "gmsg send" on group_messages for insert with check (sender_id=auth.uid() and in_group(group_id) and not is_banned(group_id, auth.uid())
  and (not exists (select 1 from groups where id=group_id and admin_only) or is_group_admin(group_id)));
drop policy if exists "gpost write" on group_posts;
create policy "gpost write" on group_posts for insert with check (author_id=auth.uid() and in_group(group_id) and not is_banned(group_id, auth.uid())
  and (not exists (select 1 from groups where id=group_id and admin_only) or is_group_admin(group_id)));
