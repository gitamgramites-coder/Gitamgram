// Server-side proxy for The Rights Foundry API (https://docs.therightsfoundry.com).
// The API key lives ONLY in this function's secrets:  supabase secrets set RIGHTS_FOUNDRY_API_KEY=...
// Endpoints used (all from the provider's docs): GET /v1/tracks, POST /v1/tracks/deep-search, GET /v1/tracks/{id},
// GET /v1/taxonomies, GET /v1/credits. Auth: "Authorization: Bearer <token>". Signed preview URLs (assets.therightsfoundry.com)
// expire after 1 hour, so we never store them: the client asks for a fresh one with action "preview".
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const BASE = "https://api.therightsfoundry.com";
const KEY = Deno.env.get("RIGHTS_FOUNDRY_API_KEY") ?? "";
const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const json = (b: unknown, status = 200, extra: Record<string, string> = {}) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json", ...extra } });

const cache = new Map<string, { at: number; v: unknown }>();           // short-lived metadata cache (per warm instance)
const TTL = 5 * 60_000;

async function rf(path: string, init: RequestInit = {}) {
  const res = await fetch(BASE + path, { ...init, headers: { Authorization: "Bearer " + KEY, "Content-Type": "application/json", ...(init.headers ?? {}) } });
  const rid = res.headers.get("X-Request-Id") ?? "";
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    await admin.from("music_api_log").insert({ fn: "rf-music", status: res.status, message: `${path}: ${body.slice(0, 300)}`, request_id: rid });
    const retry = res.headers.get("Retry-After");
    const msg = res.status === 429 ? "Music is busy right now. Try again shortly."
      : res.status === 402 ? "The music catalogue has run out of API credits. Please tell an admin."
      : res.status === 403 ? "Music access is not enabled for this feature."
      : res.status === 404 ? "Track not found." : res.status === 503 ? "Music search is temporarily unavailable." : "Music service error.";
    throw { status: res.status, msg, retryAfter: retry ? Number(retry) : undefined };
  }
  return res.json();
}

async function upsertCatalogue(tracks: any[]) {
  if (!tracks.length) return;
  const { data: lic } = await admin.from("music_licenses").select("id").eq("provider", "rightsfoundry").eq("kind", "preview").single();
  const names = [...new Set(tracks.map((t) => t.artist).filter(Boolean))];
  await admin.from("music_artists").upsert(names.map((name) => ({ name })), { onConflict: "name", ignoreDuplicates: true });
  const { data: arts } = await admin.from("music_artists").select("id,name").in("name", names);
  const aid = new Map((arts ?? []).map((a: any) => [a.name, a.id]));
  const rows = tracks.map((t) => ({
    provider: "rightsfoundry", provider_track_id: String(t.id), title: t.title, artist_id: aid.get(t.artist) ?? null,
    duration: t.duration ?? null, bpm: t.bpm ?? null, musical_key: t.musical_key ?? null, vocals: t.vocals ?? null, explicit: !!t.explicit,
    genres: t.genres ?? [], moods: t.moods ?? [], instruments: t.instruments ?? [],
    first_published: t.first_published ?? null, release_date: t.release_date ?? null, has_alternatives: !!t.has_alternatives,
    license_id: lic?.id ?? null, last_seen_at: new Date().toISOString(), updated_at: new Date().toISOString(),
  }));
  // Do not overwrite status / restricted_reason (admin decisions) on conflict.
  await admin.from("music_tracks").upsert(rows, { onConflict: "provider,provider_track_id" });
}

async function shape(tracks: any[]) {
  const ids = tracks.map((t) => String(t.id));
  const { data: rows } = await admin.from("music_tracks").select("id,provider_track_id,status").in("provider_track_id", ids);
  const byPid = new Map((rows ?? []).map((r: any) => [r.provider_track_id, r]));
  const attach = new Map<string, boolean>();
  for (const r of rows ?? []) { const { data } = await admin.rpc("track_attachable", { tid: (r as any).id }); attach.set((r as any).id, !!data); }
  return tracks.filter((t) => byPid.get(String(t.id))?.status !== "withdrawn" && byPid.get(String(t.id))?.status !== "restricted").map((t) => {
    const row: any = byPid.get(String(t.id));
    return {
      id: row?.id, providerId: String(t.id), title: t.title, artist: t.artist, album: t.album ?? null, duration: t.duration,
      genres: t.genres ?? [], moods: t.moods ?? [], bpm: t.bpm ?? null,
      previewUrl: t.asset_url,            // signed, expires in 1h; the player refreshes via action "preview"
      artwork: null,                      // the provider exposes no artwork field; UI draws a generated cover
      attachable: !!attach.get(row?.id),  // false until an admin confirms the licence allows user-generated content
    };
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (!KEY) return json({ error: "Music is not configured yet." }, 503);
  const jwt = (req.headers.get("Authorization") ?? "").replace("Bearer ", "");
  const { data: u } = await admin.auth.getUser(jwt);
  if (!u?.user) return json({ error: "Sign in to use music." }, 401);
  let b: any; try { b = await req.json(); } catch { return json({ error: "Bad request" }, 400); }
  try {
    if (b.action === "browse") {
      const q = new URLSearchParams({ page: String(Math.max(1, +b.page || 1)), limit: String(Math.min(50, +b.limit || 20)) });
      for (const k of ["search", "genre", "mood", "instrument", "vocals", "sortBy", "sortOrder", "featured"]) if (b[k] != null && b[k] !== "") q.set(k, String(b[k]));
      const key = q.toString(), hit = cache.get(key);
      if (hit && Date.now() - hit.at < TTL) return json(hit.v);
      const r = await rf("/v1/tracks?" + q);
      await upsertCatalogue(r.data ?? []);
      const out = { tracks: await shape(r.data ?? []), total: r.total, page: r.page };
      cache.set(key, { at: Date.now(), v: out }); return json(out);
    }
    if (b.action === "trending") {  // metadata from our own catalogue; previewUrl is fetched lazily via action "preview"
      const { data: top } = await admin.rpc("music_trending", { n: 20 });
      const ids = (top ?? []).map((x: any) => x.track_id);
      if (!ids.length) { const r = await rf("/v1/tracks?limit=20"); await upsertCatalogue(r.data ?? []); return json({ tracks: await shape(r.data ?? []), total: r.total, fallback: true }); }
      const { data: rows } = await admin.from("music_tracks").select("id,provider_track_id,title,duration,genres,moods,bpm,music_artists(name)").in("id", ids).eq("status", "active");
      const att = new Map<string, boolean>(); for (const r of rows ?? []) att.set((r as any).id, !!(await admin.rpc("track_attachable", { tid: (r as any).id })).data);
      return json({ tracks: ids.map((i: string) => (rows ?? []).find((r: any) => r.id === i)).filter(Boolean).map((r: any) => ({ id: r.id, providerId: r.provider_track_id, title: r.title, artist: r.music_artists?.name ?? "", duration: r.duration, genres: r.genres, moods: r.moods, bpm: r.bpm, previewUrl: null, artwork: null, attachable: !!att.get(r.id) })) });
    }
    if (b.action === "deep") {      // natural-language / mood search; needs Deep Search enabled on the token (403 otherwise)
      const r = await rf("/v1/tracks/deep-search", { method: "POST", body: JSON.stringify({ query: String(b.query ?? "").slice(0, 500), limit: Math.min(30, +b.limit || 20), page: +b.page || 1, instrumental: !!b.instrumental }) });
      await upsertCatalogue(r.data ?? []); return json({ tracks: await shape(r.data ?? []), total: r.total });
    }
    if (b.action === "preview") {   // fresh signed preview URL for one track; also detects withdrawn tracks (404)
      try {
        const r = await rf("/v1/tracks/" + encodeURIComponent(String(b.providerId)));
        const t = r.data ?? r; return json({ previewUrl: t.asset_url, expiresIn: 3600 });
      } catch (e: any) {
        if (e.status === 404) await admin.from("music_tracks").update({ status: "withdrawn", restricted_reason: "Not found at provider" }).eq("provider_track_id", String(b.providerId));
        throw e;
      }
    }
    if (b.action === "taxonomies") {
      const hit = cache.get("tax"); if (hit && Date.now() - hit.at < 24 * 3600_000) return json(hit.v);
      const r = await rf("/v1/taxonomies"); cache.set("tax", { at: Date.now(), v: r.data }); return json(r.data);
    }
    if (b.action === "credits") {   // staff only
      const { data: p } = await admin.from("profiles").select("role").eq("id", u.user.id).single();
      if (!["admin", "super_admin", "staff"].includes((p as any)?.role)) return json({ error: "Forbidden" }, 403);
      return json(await rf("/v1/credits"));
    }
    return json({ error: "Unknown action" }, 400);
  } catch (e: any) {
    if (e?.msg) return json({ error: e.msg, retryAfter: e.retryAfter }, e.status === 429 || e.status === 503 ? e.status : 502, e.retryAfter ? { "Retry-After": String(e.retryAfter) } : {});
    await admin.from("music_api_log").insert({ fn: "rf-music", status: 500, message: String(e).slice(0, 300) });
    return json({ error: "Music service error." }, 500);
  }
});
