-- GITAMGRAM 0002: posts, reels, stories, comments, highlights, notes, confessions, notifications.
create table posts (
  id uuid primary key default gen_random_uuid(), author_id uuid references profiles on delete cascade not null default auth.uid(),
  campus_id uuid references campuses not null default my_campus(),
  caption text not null check (char_length(caption) <= 2200), media_path text,
  visibility visibility not null default 'campus', is_reel boolean not null default false, music text,
  comments_off boolean not null default false, hide_counts boolean not null default false, archived boolean not null default false,
  collaborator_ids uuid[] not null default '{}', tagged_ids uuid[] not null default '{}',
  created_at timestamptz default now()
);
create table post_media (
  id uuid primary key default gen_random_uuid(), post_id uuid not null references posts on delete cascade,
  position int not null check (position between 0 and 9), media_path text not null, kind text check (kind in ('image','video')), width int, height int,
  unique (post_id, position)
);
create table comments (id uuid primary key default gen_random_uuid(), post_id uuid references posts on delete cascade not null, author_id uuid references profiles on delete cascade not null default auth.uid(), body text not null check (char_length(body) <= 500), created_at timestamptz default now());
create table likes (post_id uuid references posts on delete cascade, user_id uuid references profiles on delete cascade default auth.uid(), primary key (post_id,user_id));
create table saves (post_id uuid references posts on delete cascade, user_id uuid references profiles on delete cascade default auth.uid(), primary key (post_id,user_id));

create table stories (id uuid primary key default gen_random_uuid(), author_id uuid references profiles on delete cascade not null default auth.uid(), campus_id uuid references campuses not null default my_campus(), media_path text, text text, expires_at timestamptz not null default (now() + interval '24 hours'), created_at timestamptz default now());
create table story_views (story_id uuid references stories on delete cascade, viewer_id uuid references profiles on delete cascade default auth.uid(), primary key (story_id,viewer_id));
create table story_likes (story_id uuid references stories on delete cascade, user_id uuid references profiles on delete cascade default auth.uid(), created_at timestamptz default now(), primary key (story_id,user_id));
create table story_comments (id uuid primary key default gen_random_uuid(), story_id uuid references stories on delete cascade, user_id uuid references profiles on delete cascade default auth.uid(), body text not null check (char_length(body) between 1 and 300), created_at timestamptz default now());
create table highlights (id uuid primary key default gen_random_uuid(), owner_id uuid not null references profiles on delete cascade default auth.uid(), name text not null check (char_length(name) between 1 and 20), created_at timestamptz default now());
create table highlight_items (id uuid primary key default gen_random_uuid(), highlight_id uuid not null references highlights on delete cascade, kind text not null check (kind in ('story','post','reel')), media_url text, caption text, position int not null default 0, created_at timestamptz default now());
create table notes (user_id uuid primary key references profiles on delete cascade default auth.uid(), body text not null check (char_length(body) <= 60), created_at timestamptz not null default now());
create table confessions (id uuid primary key default gen_random_uuid(), campus_id uuid references campuses, body text not null check (char_length(body) <= 280), status text not null default 'published' check (status in ('pending','published','rejected')), created_at timestamptz default now()); -- no author column: anonymous by design
create table notifications (id uuid primary key default gen_random_uuid(), user_id uuid references profiles on delete cascade not null, actor_id uuid references profiles, kind text not null, ref_id uuid, body text, read boolean default false, created_at timestamptz default now());
create table device_tokens (user_id uuid references profiles on delete cascade, token text primary key);

alter table posts enable row level security; alter table post_media enable row level security; alter table comments enable row level security; alter table likes enable row level security; alter table saves enable row level security;
alter table stories enable row level security; alter table story_views enable row level security; alter table story_likes enable row level security; alter table story_comments enable row level security;
alter table highlights enable row level security; alter table highlight_items enable row level security; alter table notes enable row level security; alter table confessions enable row level security;
alter table notifications enable row level security; alter table device_tokens enable row level security;

create policy "posts read" on posts for select to authenticated using (
  is_verified() and (author_id=auth.uid() or (not archived and (author_id=official_id()
    or (not exists (select 1 from blocks b where (b.blocker_id=auth.uid() and b.blocked_id=author_id) or (b.blocker_id=author_id and b.blocked_id=auth.uid()))
        and (not exists (select 1 from profiles a where a.id=author_id and a.is_private) or i_follow(author_id))
        and (visibility='all' or (visibility='campus' and campus_id=my_campus()) or (visibility='followers' and i_follow(author_id))))))));
create policy "posts write" on posts for insert to authenticated with check (author_id=auth.uid() and is_verified());
create policy "official posts staff only" on posts as restrictive for insert to authenticated with check (author_id is distinct from official_id() or is_staff());
create policy "posts edit own" on posts for update to authenticated using (author_id=auth.uid()) with check (author_id=auth.uid());
create policy "posts delete own or staff" on posts for delete to authenticated using (author_id=auth.uid() or is_staff());
create policy "post media read" on post_media for select to authenticated using (exists (select 1 from posts p where p.id=post_id));
create policy "post media owner write" on post_media for all to authenticated using (exists (select 1 from posts p where p.id=post_id and p.author_id=auth.uid())) with check (exists (select 1 from posts p where p.id=post_id and p.author_id=auth.uid()));
create policy "likes read" on likes for select to authenticated using (exists (select 1 from posts p where p.id=post_id));
create policy "likes add" on likes for insert to authenticated with check (user_id=auth.uid() and exists (select 1 from posts p where p.id=post_id));
create policy "likes remove" on likes for delete to authenticated using (user_id=auth.uid());
create policy "saves own" on saves for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "comments read" on comments for select to authenticated using (exists (select 1 from posts p where p.id=post_id));
create policy "comments write" on comments for insert to authenticated with check (author_id=auth.uid() and is_verified() and exists (select 1 from posts p where p.id=post_id and not p.comments_off));
create policy "comments delete" on comments for delete to authenticated using (author_id=auth.uid() or is_staff());

create policy "stories read" on stories for select to authenticated using (author_id=auth.uid() or (is_verified() and expires_at>now() and (author_id=official_id()
  or ((not exists (select 1 from profiles a where a.id=author_id and a.is_private) or i_follow(author_id)) and (campus_id=my_campus() or i_follow(author_id))))));
create policy "stories write" on stories for insert to authenticated with check (author_id=auth.uid() and is_verified());
create policy "official stories staff only" on stories as restrictive for insert to authenticated with check (author_id is distinct from official_id() or is_staff());
create policy "stories delete own" on stories for delete to authenticated using (author_id=auth.uid() or is_staff());
create policy "story views" on story_views for all to authenticated using (viewer_id=auth.uid()) with check (viewer_id=auth.uid());
create policy "story likes read" on story_likes for select to authenticated using (user_id=auth.uid() or exists (select 1 from stories s where s.id=story_id and s.author_id=auth.uid()));
create policy "story likes add" on story_likes for insert to authenticated with check (user_id=auth.uid() and exists (select 1 from stories s where s.id=story_id and s.expires_at>now()));
create policy "story likes remove" on story_likes for delete to authenticated using (user_id=auth.uid());
create policy "story replies read" on story_comments for select to authenticated using (user_id=auth.uid() or exists (select 1 from stories s where s.id=story_id and s.author_id=auth.uid()));
create policy "story replies add" on story_comments for insert to authenticated with check (user_id=auth.uid() and exists (select 1 from stories s where s.id=story_id and s.expires_at>now()));
create policy "highlights read" on highlights for select to authenticated using (is_verified() and (owner_id=auth.uid() or not exists (select 1 from profiles p where p.id=owner_id and p.is_private) or i_follow(owner_id)));
create policy "highlights own write" on highlights for all to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy "hl items read" on highlight_items for select to authenticated using (exists (select 1 from highlights h where h.id=highlight_id));
create policy "hl items own write" on highlight_items for all to authenticated using (exists (select 1 from highlights h where h.id=highlight_id and h.owner_id=auth.uid())) with check (exists (select 1 from highlights h where h.id=highlight_id and h.owner_id=auth.uid()));
create policy "notes read" on notes for select to authenticated using (is_verified() and created_at > now() - interval '24 hours');
create policy "notes write own" on notes for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "confessions read" on confessions for select to authenticated using ((is_verified() and status='published') or is_staff());
create policy "confessions submit" on confessions for insert to authenticated with check (is_verified() and status='published');
create policy "confessions staff delete" on confessions for delete to authenticated using (is_staff());
create policy "notif own" on notifications for select to authenticated using (user_id=auth.uid());
create policy "notif mark read" on notifications for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "tokens own" on device_tokens for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

create index on posts (campus_id, created_at desc); create index on posts (author_id, created_at desc);
create index on stories (campus_id, expires_at); create index on notifications (user_id, read, created_at desc);
create index on comments (post_id, created_at); create index on follows (followee_id);
