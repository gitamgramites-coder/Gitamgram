-- Promotions: admin-created sponsored posts, reels and stories shown to every user.
create table if not exists promotions (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('post','reel','story')),
  media_path text not null, is_video boolean not null default false,
  caption text not null check (char_length(caption) <= 200), cta_text text check (char_length(cta_text) <= 24),
  link_url text check (link_url is null or link_url ~* '^https?://'),
  campus_id uuid references campuses,                       -- null = all campuses
  every_n int not null default 5 check (every_n between 1 and 50),   -- shown after every N posts/reels (1 = after every one)
  active boolean not null default true, starts_at timestamptz, ends_at timestamptz,
  created_by uuid references profiles default auth.uid(), created_at timestamptz not null default now());
create table if not exists promotion_events (
  id bigserial primary key, promotion_id uuid references promotions on delete cascade, user_id uuid references profiles default auth.uid(),
  kind text not null check (kind in ('view','click')), created_at timestamptz not null default now());
create index on promotion_events (promotion_id, kind);
alter table promotions enable row level security; alter table promotion_events enable row level security;
create policy "promos read" on promotions for select using (is_verified() and (is_staff() or (active and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now()))));
create policy "promos staff write" on promotions for all using (is_staff()) with check (is_staff());
create policy "promo events insert" on promotion_events for insert with check (user_id = auth.uid());
create policy "promo events staff read" on promotion_events for select using (is_staff());
insert into storage.buckets (id, name, public) values ('promotions','promotions',true) on conflict do nothing;
create policy "promo media staff upload" on storage.objects for insert to authenticated with check (bucket_id='promotions' and is_staff());
