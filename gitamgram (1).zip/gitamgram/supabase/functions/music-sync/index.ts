// Pulls newly released, freely licensed (Creative Commons) tracks from Jamendo into the `tracks` table.
// Run on a schedule (Supabase Dashboard > Edge Functions > Schedule, e.g. every 6 hours).
// Secrets: JAMENDO_CLIENT_ID. Honour each track's licence terms; Jamendo free tier is for non-commercial use,
// so switch `source` to a commercial catalogue (e.g. a licensed provider) before monetising.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
Deno.serve(async () => {
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const url = `https://api.jamendo.com/v3.0/tracks/?client_id=${Deno.env.get("JAMENDO_CLIENT_ID")}&format=json&limit=30&order=releasedate_desc&audioformat=mp32&include=musicinfo`;
  const res = await (await fetch(url)).json();
  const rows = (res.results ?? []).map((t: any) => ({
    title: t.name, artist: t.artist_name, duration: t.duration, audio_url: t.audio, cover_url: t.image,
    mood: t.musicinfo?.tags?.genres?.[0] ?? "New", source: "jamendo", external_id: "jamendo:" + t.id,
  }));
  const { error } = await db.from("tracks").upsert(rows, { onConflict: "external_id", ignoreDuplicates: true });
  return Response.json({ ok: !error, fetched: rows.length, error: error?.message });
});
