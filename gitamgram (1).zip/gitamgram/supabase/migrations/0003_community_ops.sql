-- GITAMGRAM 0003: clubs, events, messaging, groups, help desk, moderation, promotions, storage, hardening.
create table clubs (id uuid primary key default gen_random_uuid(), campus_id uuid references campuses not null, slug text unique not null, name text not null, about text, category text, is_verified boolean default false, owner_id uuid references profiles, privacy text not null default 'public' check (privacy in ('public','private')));
create table club_members (club_id uuid references clubs on delete cascade, user_id uuid references profiles on delete cascade, primary key (club_id,user_id));
create table club_join_requests (club_id uuid references clubs on delete cascade, user_id uuid references profiles on delete cascade default auth.uid(), created_at timestamptz default now(), primary key (club_id,user_id));
create table events (id uuid primary key default gen_random_uuid(), club_id uuid references clubs, campus_id uuid references campuses, title text not null, description text, starts_at timestamptz not null, place text, capacity int,
  registration_url text check (registration_url is null or registration_url ~* '^https?://'), link_clicks int not null default 0);
create table event_attendees (event_id uuid references events on delete cascade, user_id uuid references profiles on delete cascade, remind boolean default false, primary key (event_id,user_id));

create table conversations (id uuid primary key default gen_random_uuid(), is_group boolean default false, created_by uuid default auth.uid(), created_at timestamptz default now());
create table conversation_members (conversation_id uuid references conversations on delete cascade, user_id uuid references profiles on delete cascade, accepted boolean default false, primary key (conversation_id,user_id));
create table messages (id uuid primary key default gen_random_uuid(), conversation_id uuid references conversations on delete cascade not null, sender_id uuid references profiles not null default auth.uid(),
  body text not null check (char_length(body) <= 2000), media_url text, media_kind text check (media_kind in ('image','video')), reply_to uuid references messages on delete set null, deleted_at timestamptz, created_at timestamptz default now());

create type group_kind as enum ('group','community');
create type group_privacy as enum ('public','private');
create table groups (id uuid primary key default gen_random_uuid(), kind group_kind not null default 'group', privacy group_privacy not null default 'public',
  name text not null check (char_length(name) between 2 and 50), description text default '', campus_id uuid references campuses, owner_id uuid references profiles not null default auth.uid(), admin_only boolean not null default false, created_at timestamptz default now());
create table group_members (group_id uuid references groups on delete cascade, user_id uuid references profiles on delete cascade, role text default 'member' check (role in ('owner','admin','member')), primary key (group_id,user_id));
create table group_join_requests (group_id uuid references groups on delete cascade, user_id uuid references profiles on delete cascade, created_at timestamptz default now(), primary key (group_id,user_id));
create table group_messages (id uuid primary key default gen_random_uuid(), group_id uuid references groups on delete cascade not null, sender_id uuid references profiles not null default auth.uid(), body text not null check (char_length(body)<=2000), created_at timestamptz default now());
create table group_posts (id uuid primary key default gen_random_uuid(), group_id uuid references groups on delete cascade not null, author_id uuid references profiles not null default auth.uid(), body text not null check (char_length(body)<=500), created_at timestamptz default now());
create table group_bans (group_id uuid references groups on delete cascade, user_id uuid references profiles on delete cascade, banned_by uuid references profiles default auth.uid(), created_at timestamptz default now(), primary key (group_id,user_id));

create type ticket_status as enum ('not_started','processing','solved');
create table tickets (id bigint generated always as identity primary key, code text generated always as ('T-' || (1000 + id)) stored, user_id uuid not null references profiles on delete cascade, username text not null,
  category text not null, subject text not null check (char_length(subject) between 3 and 80), description text not null check (char_length(description) between 5 and 800),
  status ticket_status not null default 'not_started', admin_response text, handled_by uuid references profiles, email text, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table reports (id uuid primary key default gen_random_uuid(), reporter_id uuid references profiles default auth.uid(), target_type text not null, target_id uuid not null, reason text not null, status text default 'open', created_at timestamptz default now());
create table moderation_actions (id uuid primary key default gen_random_uuid(), moderator_id uuid references profiles not null, report_id uuid references reports, action text not null, created_at timestamptz default now());
create table promotions (id uuid primary key default gen_random_uuid(), kind text not null check (kind in ('post','reel','story')), media_path text not null, is_video boolean not null default false,
  caption text not null check (char_length(caption) <= 200), cta_text text check (char_length(cta_text) <= 24), link_url text check (link_url is null or link_url ~* '^https?://'),
  campus_id uuid references campuses, every_n int not null default 5 check (every_n between 1 and 50), active boolean not null default true, starts_at timestamptz, ends_at timestamptz,
  created_by uuid references profiles default auth.uid(), created_at timestamptz not null default now());
create table promotion_events (id bigserial primary key, promotion_id uuid references promotions on delete cascade, user_id uuid references profiles default auth.uid(), kind text not null check (kind in ('view','click')), created_at timestamptz not null default now());

-- Helpers
create function in_conversation(c uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists (select 1 from conversation_members where conversation_id=c and user_id=auth.uid()) $$;
create function in_group(g uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists (select 1 from group_members where group_id=g and user_id=auth.uid()) $$;
create function owns_group(g uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists (select 1 from groups where id=g and owner_id=auth.uid()) $$;
create function group_is_public(g uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists (select 1 from groups where id=g and privacy='public') $$;
create function is_group_admin(g uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists (select 1 from group_members where group_id=g and user_id=auth.uid() and role in ('owner','admin')) $$;
create function is_banned(g uuid, u uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists (select 1 from group_bans where group_id=g and user_id=u) $$;
create function is_club_admin(c uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists (select 1 from clubs where id=c and owner_id=auth.uid()) $$;
create function assign_club_admin(club uuid, uname text) returns void language plpgsql security definer set search_path=public as $$
declare pid uuid; begin
  if not is_staff() then raise exception 'staff only'; end if;
  select id into pid from profiles where username = lower(regexp_replace(uname,'^@',''));
  if pid is null then raise exception 'No user with that username'; end if;
  update clubs set owner_id = pid where id = club;
end $$;
create function delete_message(mid uuid) returns void language sql security definer set search_path=public as $$
  update messages set body='', media_url=null, media_kind=null, deleted_at=now() where id=mid and sender_id=auth.uid() $$;
create function bump_event_click(eid uuid) returns void language sql security definer set search_path=public as $$ update events set link_clicks=link_clicks+1 where id=eid and is_verified() $$;

create function ticket_before_insert() returns trigger language plpgsql security definer set search_path=public as $$
begin new.user_id := auth.uid(); new.username := (select username from profiles where id=auth.uid());
  new.email := (select email from auth.users where id=auth.uid());
  new.status := 'not_started'; new.admin_response := null; new.handled_by := null; return new; end $$;
create trigger trg_ticket_ins before insert on tickets for each row execute function ticket_before_insert();
create function ticket_before_update() returns trigger language plpgsql security definer set search_path=public as $$
begin new.username:=old.username; new.user_id:=old.user_id; new.subject:=old.subject; new.description:=old.description; new.email:=old.email; new.handled_by:=auth.uid(); new.updated_at:=now(); return new; end $$;
create trigger trg_ticket_upd before update on tickets for each row execute function ticket_before_update();
create function ticket_notify() returns trigger language plpgsql security definer set search_path=public as $$
begin if new.status is distinct from old.status or new.admin_response is distinct from old.admin_response then
  insert into notifications(user_id,actor_id,kind,body) values (new.user_id, official_id(), 'ticket', 'updated your ticket '||new.code||': '||replace(new.status::text,'_',' ')); end if; return new; end $$;
create trigger trg_ticket_notify after update on tickets for each row execute function ticket_notify();

-- RLS
alter table clubs enable row level security; alter table club_members enable row level security; alter table club_join_requests enable row level security; alter table events enable row level security; alter table event_attendees enable row level security;
alter table conversations enable row level security; alter table conversation_members enable row level security; alter table messages enable row level security;
alter table groups enable row level security; alter table group_members enable row level security; alter table group_join_requests enable row level security; alter table group_messages enable row level security; alter table group_posts enable row level security; alter table group_bans enable row level security;
alter table tickets enable row level security; alter table reports enable row level security; alter table moderation_actions enable row level security; alter table promotions enable row level security; alter table promotion_events enable row level security;

create policy "clubs read" on clubs for select to authenticated using (is_verified());
create policy "clubs create" on clubs for insert to authenticated with check (owner_id=auth.uid() and is_verified() and is_verified=false);
create policy "clubs update" on clubs for update to authenticated using (is_staff() or owner_id=auth.uid()) with check (is_staff() or (owner_id=auth.uid() and is_verified=false));
create policy "club members read" on club_members for select to authenticated using (user_id=auth.uid() or is_club_admin(club_id) or is_staff() or exists (select 1 from clubs c where c.id=club_id and c.privacy='public'));
create policy "club join" on club_members for insert to authenticated with check ((user_id=auth.uid() and exists (select 1 from clubs c where c.id=club_id and c.privacy='public') and is_verified()) or is_club_admin(club_id) or is_staff());
create policy "club leave" on club_members for delete to authenticated using (user_id=auth.uid() or is_club_admin(club_id) or is_staff());
create policy "club req read" on club_join_requests for select to authenticated using (user_id=auth.uid() or is_club_admin(club_id) or is_staff());
create policy "club req create" on club_join_requests for insert to authenticated with check (user_id=auth.uid() and is_verified());
create policy "club req resolve" on club_join_requests for delete to authenticated using (user_id=auth.uid() or is_club_admin(club_id) or is_staff());
create policy "events read" on events for select to authenticated using (is_verified());
create policy "events write" on events for all to authenticated using (is_staff() or exists (select 1 from clubs c where c.id=club_id and c.owner_id=auth.uid())) with check (is_staff() or exists (select 1 from clubs c where c.id=club_id and c.owner_id=auth.uid()));
create policy "attendees own" on event_attendees for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

create policy "conv read" on conversations for select to authenticated using (in_conversation(id) or created_by=auth.uid());
create policy "conv create" on conversations for insert to authenticated with check (is_verified() and created_by=auth.uid());
create policy "conv members read" on conversation_members for select to authenticated using (in_conversation(conversation_id));
create policy "conv members add" on conversation_members for insert to authenticated with check (exists (select 1 from conversations c where c.id=conversation_id and c.created_by=auth.uid()));
create policy "conv members self update" on conversation_members for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "conv members leave" on conversation_members for delete to authenticated using (user_id=auth.uid());
create policy "messages read" on messages for select to authenticated using (in_conversation(conversation_id));
create policy "messages send" on messages for insert to authenticated with check (sender_id=auth.uid() and in_conversation(conversation_id) and is_verified());

create policy "groups discover" on groups for select to authenticated using (is_verified());
create policy "groups create" on groups for insert to authenticated with check (owner_id=auth.uid() and is_verified());
create policy "groups edit" on groups for update to authenticated using (owner_id=auth.uid() or is_group_admin(id)) with check (owner_id=auth.uid() or is_group_admin(id));
create policy "groups delete" on groups for delete to authenticated using (owner_id=auth.uid() or is_staff());
create policy "gmembers read" on group_members for select to authenticated using (in_group(group_id) or group_is_public(group_id));
create policy "gmembers join or invite" on group_members for insert to authenticated with check (not is_banned(group_id,user_id) and (
  (user_id=auth.uid() and role='member' and group_is_public(group_id) and is_verified())
  or (is_group_admin(group_id) and role='member')
  or (in_group(group_id) and role='member' and follows_user(auth.uid(),user_id))
  or (user_id=auth.uid() and role='owner' and owns_group(group_id))));
create policy "gmembers assign admin" on group_members for update to authenticated using (is_group_admin(group_id)) with check (role in ('admin','member'));
create policy "gmembers leave or remove" on group_members for delete to authenticated using (user_id=auth.uid() or (is_group_admin(group_id) and role<>'owner'));
create policy "grequests read" on group_join_requests for select to authenticated using (user_id=auth.uid() or owns_group(group_id) or is_group_admin(group_id));
create policy "grequests create" on group_join_requests for insert to authenticated with check (user_id=auth.uid() and is_verified());
create policy "grequests resolve" on group_join_requests for delete to authenticated using (user_id=auth.uid() or owns_group(group_id) or is_group_admin(group_id));
create policy "gmsg read" on group_messages for select to authenticated using (in_group(group_id));
create policy "gmsg send" on group_messages for insert to authenticated with check (sender_id=auth.uid() and in_group(group_id) and not is_banned(group_id,auth.uid()) and (not exists (select 1 from groups where id=group_id and admin_only) or is_group_admin(group_id)));
create policy "gpost read" on group_posts for select to authenticated using (in_group(group_id) or group_is_public(group_id));
create policy "gpost write" on group_posts for insert to authenticated with check (author_id=auth.uid() and in_group(group_id) and not is_banned(group_id,auth.uid()) and (not exists (select 1 from groups where id=group_id and admin_only) or is_group_admin(group_id)));
create policy "gpost delete" on group_posts for delete to authenticated using (author_id=auth.uid() or is_group_admin(group_id) or is_staff());
create policy "bans admin" on group_bans for all to authenticated using (is_group_admin(group_id)) with check (is_group_admin(group_id));
create policy "bans self read" on group_bans for select to authenticated using (user_id=auth.uid());

create policy "tickets read" on tickets for select to authenticated using (user_id=auth.uid() or is_staff());
create policy "tickets create" on tickets for insert to authenticated with check (user_id=auth.uid());
create policy "tickets staff update" on tickets for update to authenticated using (is_staff()) with check (is_staff());
create policy "reports create" on reports for insert to authenticated with check (reporter_id=auth.uid());
create policy "reports staff read" on reports for select to authenticated using (is_staff());
create policy "reports staff update" on reports for update to authenticated using (is_staff());
create policy "mod actions staff" on moderation_actions for all to authenticated using (is_staff()) with check (is_staff());
create policy "promos read" on promotions for select to authenticated using (is_verified() and (is_staff() or (active and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>now()))));
create policy "promos staff write" on promotions for all to authenticated using (is_staff()) with check (is_staff());
create policy "promo events insert" on promotion_events for insert to authenticated with check (user_id=auth.uid());
create policy "promo events staff read" on promotion_events for select to authenticated using (is_staff());

-- Storage: avatars (public read), media + chat-media (private), verification-docs (owner + staff), promotions (public read, staff upload)
insert into storage.buckets (id,name,public) values ('avatars','avatars',true),('media','media',false),('verification-docs','verification-docs',false),('chat-media','chat-media',false),('promotions','promotions',true) on conflict do nothing;
create policy "own folder upload" on storage.objects for insert to authenticated with check (bucket_id in ('avatars','media','verification-docs','chat-media') and (storage.foldername(name))[1]=auth.uid()::text);
create policy "own folder update" on storage.objects for update to authenticated using (bucket_id in ('avatars','media','verification-docs','chat-media') and (storage.foldername(name))[1]=auth.uid()::text);
create policy "own folder delete" on storage.objects for delete to authenticated using (bucket_id in ('avatars','media','verification-docs','chat-media') and (storage.foldername(name))[1]=auth.uid()::text);
create policy "private media read" on storage.objects for select to authenticated using (bucket_id in ('media','chat-media') and is_verified());
create policy "verification docs read" on storage.objects for select to authenticated using (bucket_id='verification-docs' and ((storage.foldername(name))[1]=auth.uid()::text or is_staff()));
create policy "promotions staff upload" on storage.objects for insert to authenticated with check (bucket_id='promotions' and is_staff());

-- Hardening: nothing callable by anonymous users; trigger-only functions callable by no one.
do $$ declare f record; begin
  for f in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' loop
    execute format('revoke execute on function %s from public, anon', f.sig); end loop;
end $$;
revoke execute on function protect_profile(), enforce_gitam_email(), handle_new_user(), student_record_email(), auto_follow_official(), approve_all_on_public(), ticket_before_insert(), ticket_before_update(), ticket_notify() from authenticated;
create index on messages (conversation_id, created_at); create index on group_messages (group_id, created_at); create index on group_posts (group_id, created_at desc); create index on promotion_events (promotion_id, kind);
