-- Verified (blue) badge is separate from student-ID verification.
alter table profiles add column if not exists has_badge boolean not null default false;

create table if not exists badge_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles on delete cascade not null,
  category text not null, reason text not null check (char_length(reason) between 15 and 300), proof_link text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  note text, reviewer_id uuid references profiles, reviewed_at timestamptz, created_at timestamptz default now()
);
alter table badge_requests enable row level security;
create policy "badge req own/staff read" on badge_requests for select using (user_id=auth.uid() or is_staff());
create policy "badge req create" on badge_requests for insert with check (user_id=auth.uid() and status='pending' and is_verified());
create policy "badge req staff review" on badge_requests for update using (is_staff());

-- Only staff may change the badge flag (extends protect_profile from 0001).
create or replace function protect_profile() returns trigger language plpgsql security definer as $$
begin
  if not is_staff() and (new.role<>old.role or new.status<>old.status or new.has_badge<>old.has_badge) then
    raise exception 'role/status/badge can only be changed by staff';
  end if; return new;
end $$;

-- Approving a request flips the badge and writes an audit row.
create or replace function review_badge(req uuid, approve boolean, reviewer_note text default null) returns void
language plpgsql security definer set search_path=public as $$
declare r badge_requests;
begin
  if not is_staff() then raise exception 'staff only'; end if;
  update badge_requests set status=case when approve then 'approved' else 'rejected' end, note=reviewer_note, reviewer_id=auth.uid(), reviewed_at=now() where id=req returning * into r;
  update profiles set has_badge=approve where id=r.user_id;
  insert into audit_logs(actor_id,action,detail) values (auth.uid(), case when approve then 'badge_granted' else 'badge_declined' end, jsonb_build_object('user',r.user_id,'request',req));
end $$;

-- Campus scope: clients filter by campus_id (null = visible everywhere); 'Tri-Campus' = no filter.
create index if not exists posts_campus_idx on posts (campus_id, created_at desc);
create index if not exists stories_campus_idx on stories (campus_id, expires_at);
alter table confessions add column if not exists campus_id uuid references campuses;
