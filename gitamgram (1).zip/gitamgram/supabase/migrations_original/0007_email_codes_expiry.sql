-- Email verification codes (sent by the send-code edge function) + 24h expiry for stories and notes.
create table if not exists email_codes (
  email text primary key,
  code_hash text not null,
  expires_at timestamptz not null,
  attempts int not null default 0,
  last_sent_at timestamptz not null default now()
);
alter table email_codes enable row level security;   -- no policies: only the service role (edge functions) can read or write

-- Notes: one live note per user, visible for 24 hours.
create table if not exists notes (
  user_id uuid primary key references profiles on delete cascade,
  body text not null check (char_length(body) <= 60),
  created_at timestamptz not null default now()
);
alter table notes enable row level security;
create policy "notes read" on notes for select using (is_verified() and created_at > now() - interval '24 hours');
create policy "notes write own" on notes for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Stories only show for 24 hours; expired ones stay visible to the owner (archive).
-- (stories.expires_at already exists from 0001; make sure it defaults to created_at + 24h)
alter table stories alter column expires_at set default (now() + interval '24 hours');

-- Posts and reels: owner controls.
alter table posts add column if not exists comments_off boolean not null default false;
alter table posts add column if not exists hide_counts boolean not null default false;
alter table posts add column if not exists archived boolean not null default false;
alter table posts add column if not exists collaborator_ids uuid[] not null default '{}';
alter table posts add column if not exists tagged_ids uuid[] not null default '{}';
-- archived posts are visible only to their owner
drop policy if exists "posts read" on posts;
create policy "posts read" on posts for select using (
  is_verified() and (author_id = auth.uid() or (not archived and (
    author_id = official_id()
    or (not exists (select 1 from blocks b where (b.blocker_id=auth.uid() and b.blocked_id=author_id) or (b.blocker_id=author_id and b.blocked_id=auth.uid()))
        and (not exists (select 1 from profiles a where a.id=author_id and a.is_private) or i_follow(author_id))
        and (visibility='all' or (visibility='campus' and campus_id=my_campus()) or (visibility='followers' and i_follow(author_id))))))));
-- comments blocked when the owner turned them off
drop policy if exists "comments insert" on comments;
create policy "comments insert" on comments for insert with check (
  author_id = auth.uid() and is_verified() and not exists (select 1 from posts p where p.id = post_id and p.comments_off));
