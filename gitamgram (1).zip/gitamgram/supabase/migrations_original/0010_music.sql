-- Music library: tracks everyone can use in stories, posts and reels.
create table if not exists tracks (
  id uuid primary key default gen_random_uuid(),
  title text not null, artist text not null, mood text,
  duration int,                       -- seconds
  audio_url text not null,            -- storage URL (uploads) or licensed preview/stream URL
  cover_url text,
  source text not null default 'upload' check (source in ('upload','jamendo','licensed')),
  external_id text unique,            -- id in the external catalogue (prevents duplicates when syncing)
  plays bigint not null default 0,
  added_by uuid references profiles,
  added_at timestamptz not null default now()
);
alter table tracks enable row level security;
create policy "tracks read" on tracks for select using (is_verified());
create policy "tracks admin write" on tracks for all using (is_staff()) with check (is_staff());

-- Attach a track (and clip start in seconds) to content
alter table posts   add column if not exists track_id uuid references tracks, add column if not exists track_start int default 0;
alter table reels   add column if not exists track_id uuid references tracks, add column if not exists track_start int default 0;
alter table stories add column if not exists track_id uuid references tracks, add column if not exists track_start int default 0;
create table if not exists saved_tracks (user_id uuid references profiles on delete cascade default auth.uid(), track_id uuid references tracks on delete cascade, primary key (user_id, track_id));
alter table saved_tracks enable row level security;
create policy "saved tracks own" on saved_tracks for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create or replace function bump_track_plays(tid uuid) returns void language sql security definer set search_path=public as $$ update tracks set plays = plays + 1 where id = tid $$;

-- Uploaded audio lives in a public-read bucket; only staff can upload.
insert into storage.buckets (id, name, public) values ('music','music',true) on conflict do nothing;
create policy "music upload staff" on storage.objects for insert to authenticated with check (bucket_id='music' and is_staff());

-- New tracks notify everyone (one notification row per verified user; fan out with a trigger or cron if your user base is large).
create or replace function notify_new_track() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into notifications(user_id, actor_id, kind, body)
  select p.id, official_id(), 'new_music', 'added new music: ' || new.title || ' · ' || new.artist from profiles p where p.status = 'verified';
  return new;
end $$;
drop trigger if exists trg_new_track on tracks;
create trigger trg_new_track after insert on tracks for each row execute function notify_new_track();
