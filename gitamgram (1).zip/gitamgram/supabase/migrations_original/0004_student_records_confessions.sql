-- Per-campus student records, filed under the campus chosen at registration.
-- Phone numbers and student IDs are sensitive: readable only by the student and staff.
create table if not exists student_records (
  user_id uuid primary key references profiles on delete cascade,
  campus_id uuid references campuses not null,
  sn bigint generated always as identity,            -- running serial; the admin table shows the per-campus row number
  phone text not null check (phone ~ '^\+91 ?[6-9][0-9]{4} ?[0-9]{5}$'),
  student_id text not null check (student_id ~ '^[A-Za-z0-9][A-Za-z0-9/-]{3,19}$'),
  created_at timestamptz default now(),
  unique (campus_id, student_id)
);
alter table student_records enable row level security;
create policy "own record read" on student_records for select using (user_id=auth.uid());
create policy "staff read records" on student_records for select using (is_staff());
create policy "own record insert" on student_records for insert with check (user_id=auth.uid() and campus_id=(select campus_id from profiles where id=auth.uid()));
create policy "own record update" on student_records for update using (user_id=auth.uid());

-- What the admin "Campuses > <campus>" table shows.
create or replace view campus_students with (security_invoker=true) as
select row_number() over (partition by r.campus_id order by r.created_at) as sn_no,
       r.campus_id, p.avatar_url as profile_pic, p.display_name as name, r.phone as ph_no,
       u.email as email_id, r.student_id as id_no
from student_records r join profiles p on p.id=r.user_id join auth.users u on u.id=r.user_id;
revoke all on campus_students from anon, authenticated;
grant select on campus_students to authenticated;  -- security_invoker + RLS keeps it staff/owner only

-- Confessions publish instantly (no approval). Reports + staff removal remain.
alter table confessions alter column status set default 'published';
drop policy if exists "confessions submit" on confessions;
create policy "confessions submit" on confessions for insert with check (is_verified() and status='published');
create policy "confessions staff delete" on confessions for delete using (is_staff());
