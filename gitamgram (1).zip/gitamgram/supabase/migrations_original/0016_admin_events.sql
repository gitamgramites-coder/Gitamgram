-- Staff-created events with an optional external registration link.
alter table events add column if not exists description text, add column if not exists registration_url text check (registration_url is null or registration_url ~* '^https?://'),
  add column if not exists link_clicks int not null default 0;
alter table events alter column campus_id drop not null;   -- null = all campuses
create or replace function bump_event_click(eid uuid) returns void language sql security definer set search_path=public as $$ update events set link_clicks = link_clicks + 1 where id = eid $$;
drop policy if exists "events staff/owner write" on events;
create policy "events staff/club admin write" on events for all
  using (is_staff() or exists (select 1 from clubs c where c.id = club_id and c.owner_id = auth.uid()))
  with check (is_staff() or exists (select 1 from clubs c where c.id = club_id and c.owner_id = auth.uid()));
