// Sends a 6-digit email verification code to a GITAM address.
// Secrets: RESEND_API_KEY, MAIL_FROM (e.g. "GITAMGRAM <no-reply@yourdomain.com>")
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, apikey, content-type" };
const sha = async (s: string) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)))).map(b => b.toString(16).padStart(2, "0")).join("");
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const { email } = await req.json().catch(() => ({}));
  const e = String(email || "").trim().toLowerCase();
  if (!/^[^@\s]+@(gitam\.edu|gitam\.in)$/.test(e)) return Response.json({ error: "Only GITAM university emails can register." }, { status: 400, headers: cors });
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: prev } = await db.from("email_codes").select("last_sent_at").eq("email", e).maybeSingle();
  if (prev && Date.now() - new Date(prev.last_sent_at).getTime() < 30_000) return Response.json({ error: "Please wait 30 seconds before asking for a new code." }, { status: 429, headers: cors });
  const code = String(crypto.getRandomValues(new Uint32Array(1))[0] % 1_000_000).padStart(6, "0");
  await db.from("email_codes").upsert({ email: e, code_hash: await sha(code + e), expires_at: new Date(Date.now() + 10 * 60_000).toISOString(), attempts: 0, last_sent_at: new Date().toISOString() });
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: "Bearer " + Deno.env.get("RESEND_API_KEY"), "Content-Type": "application/json" },
    body: JSON.stringify({ from: Deno.env.get("MAIL_FROM"), to: e, subject: "Your GITAMGRAM verification code", html: `<p>Your GITAMGRAM code is <b style="font-size:22px;letter-spacing:3px">${code}</b></p><p>It expires in 10 minutes. If you did not request it, ignore this email.</p>` }),
  });
  if (!r.ok) return Response.json({ error: "Could not send the email. Try again." }, { status: 502, headers: cors });
  return Response.json({ ok: true }, { headers: cors });
});
