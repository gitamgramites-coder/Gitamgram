// Scheduled catalogue refresh for The Rights Foundry music. Run every 6h:
//   Dashboard > Edge Functions > rf-sync > Schedule, or pg_cron + pg_net with header  x-cron-secret: <CRON_SECRET>.
// Secrets: RIGHTS_FOUNDRY_API_KEY, CRON_SECRET. Optional: RF_SYNC_PAGES (default 3), RF_VERIFY_BATCH (default 15).
// Each provider call can cost API credits (see GET /v1/credits -> costs), so the work per run is capped.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const BASE = "https://api.therightsfoundry.com", KEY = Deno.env.get("RIGHTS_FOUNDRY_API_KEY") ?? "";
const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const call = async (path: string) => {
  const r = await fetch(BASE + path, { headers: { Authorization: "Bearer " + KEY } });
  if (!r.ok) { await db.from("music_api_log").insert({ fn: "rf-sync", status: r.status, message: path, request_id: r.headers.get("X-Request-Id") }); throw { status: r.status, retry: r.headers.get("Retry-After") }; }
  return r.json();
};
Deno.serve(async (req) => {
  if (req.headers.get("x-cron-secret") !== Deno.env.get("CRON_SECRET")) return new Response("Forbidden", { status: 403 });
  const out = { inserted: 0, updated: 0, withdrawn: 0, restored: 0, errors: 0 };
  try {
    const { data: lic } = await db.from("music_licenses").select("id").eq("provider", "rightsfoundry").eq("kind", "preview").single();
    const pages = +(Deno.env.get("RF_SYNC_PAGES") ?? 3);
    for (let page = 1; page <= pages; page++) {
      // newest first: sortBy=first_published is a documented value
      const r = await call(`/v1/tracks?sortBy=first_published&sortOrder=desc&limit=100&page=${page}`);
      const tracks: any[] = r.data ?? []; if (!tracks.length) break;
      const names = [...new Set(tracks.map((t) => t.artist).filter(Boolean))];
      await db.from("music_artists").upsert(names.map((name) => ({ name })), { onConflict: "name", ignoreDuplicates: true });
      const { data: arts } = await db.from("music_artists").select("id,name").in("name", names);
      const aid = new Map((arts ?? []).map((a: any) => [a.name, a.id]));
      const { data: have } = await db.from("music_tracks").select("provider_track_id,status").in("provider_track_id", tracks.map((t) => String(t.id)));
      const known = new Map((have ?? []).map((h: any) => [h.provider_track_id, h.status]));
      const rows = tracks.map((t) => ({
        provider: "rightsfoundry", provider_track_id: String(t.id), title: t.title, artist_id: aid.get(t.artist) ?? null, duration: t.duration ?? null,
        bpm: t.bpm ?? null, musical_key: t.musical_key ?? null, vocals: t.vocals ?? null, explicit: !!t.explicit, genres: t.genres ?? [], moods: t.moods ?? [],
        instruments: t.instruments ?? [], first_published: t.first_published ?? null, release_date: t.release_date ?? null, has_alternatives: !!t.has_alternatives,
        license_id: lic?.id ?? null, is_new: !known.has(String(t.id)), last_seen_at: new Date().toISOString(), updated_at: new Date().toISOString(),
      }));
      // upsert never touches status/restricted_reason, so admin restrictions survive; duplicates are impossible (unique provider+id)
      await db.from("music_tracks").upsert(rows.map(({ is_new, ...r }) => ({ ...r, ...(known.has(r.provider_track_id) ? {} : { is_new }) })), { onConflict: "provider,provider_track_id" });
      out.inserted += rows.filter((x) => x.is_new).length; out.updated += rows.filter((x) => !x.is_new).length;
    }
    await db.from("music_tracks").update({ is_new: false }).lt("created_at", new Date(Date.now() - 14 * 864e5).toISOString()).eq("is_new", true);
    // Detect withdrawn tracks: re-check the least recently seen ones individually (404 = gone).
    const { data: stale } = await db.from("music_tracks").select("provider_track_id,status").neq("status", "restricted").order("last_seen_at", { ascending: true }).limit(+(Deno.env.get("RF_VERIFY_BATCH") ?? 15));
    for (const s of stale ?? []) {
      try { await call("/v1/tracks/" + s.provider_track_id); await db.from("music_tracks").update({ last_seen_at: new Date().toISOString(), ...(s.status === "withdrawn" ? { status: "active", restricted_reason: null } : {}) }).eq("provider_track_id", s.provider_track_id); if (s.status === "withdrawn") out.restored++; }
      catch (e: any) { if (e.status === 404) { await db.from("music_tracks").update({ status: "withdrawn", restricted_reason: "Not found at provider" }).eq("provider_track_id", s.provider_track_id); out.withdrawn++; } else out.errors++; }
    }
    const tax = await call("/v1/taxonomies");
    const g = (tax.data?.genre ?? []).map((x: any) => ({ value: x.value, kind: "genre", track_count: x.count, updated_at: new Date().toISOString() }));
    if (g.length) await db.from("music_genres").upsert(g, { onConflict: "value" });
  } catch (e: any) { out.errors++; if (e?.status === 429 || e?.status === 503) return Response.json({ ...out, retryAfter: e.retry }, { status: 503 }); }
  return Response.json(out);
});
