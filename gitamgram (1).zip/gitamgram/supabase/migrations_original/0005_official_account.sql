-- Official account "GITAMGRAM Tri": followed by everyone, visible on every campus.
alter table profiles add column if not exists is_official boolean not null default false;
-- Create the auth user for the official account in the Supabase dashboard (Auth > Users), then:
--   update profiles set is_official=true, username='gitamgram.tri', display_name='GITAMGRAM Tri', has_badge=true where id='<that user id>';
-- Only one official account may exist.
create unique index if not exists one_official on profiles (is_official) where is_official;

create or replace function official_id() returns uuid language sql stable security definer set search_path=public as
$$ select id from profiles where is_official limit 1 $$;

-- Every new profile automatically follows the official account.
create or replace function auto_follow_official() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if not new.is_official and official_id() is not null then
    insert into follows(follower_id,followee_id) values (new.id, official_id()) on conflict do nothing;
  end if; return new;
end $$;
drop trigger if exists trg_auto_follow_official on profiles;
create trigger trg_auto_follow_official after insert on profiles for each row execute function auto_follow_official();

-- Back-fill existing members.
insert into follows(follower_id,followee_id)
select p.id, official_id() from profiles p where official_id() is not null and not p.is_official
on conflict do nothing;

-- Users cannot unfollow the official account.
drop policy if exists "follows own" on follows;
create policy "follows insert own" on follows for insert with check (follower_id=auth.uid());
create policy "follows delete own except official" on follows for delete using (follower_id=auth.uid() and followee_id is distinct from official_id());

-- Official posts and stories are visible to every verified user regardless of campus.
drop policy if exists "posts read" on posts;
create policy "posts read" on posts for select using (
  is_verified() and (
    author_id = official_id()
    or (not exists (select 1 from blocks b where (b.blocker_id=auth.uid() and b.blocked_id=author_id) or (b.blocker_id=author_id and b.blocked_id=auth.uid()))
        and (author_id=auth.uid() or visibility='all' or (visibility='campus' and campus_id=my_campus())
             or (visibility='followers' and exists (select 1 from follows f where f.follower_id=auth.uid() and f.followee_id=author_id))))));
drop policy if exists "stories read" on stories;
create policy "stories read" on stories for select using (
  is_verified() and expires_at>now() and (author_id=auth.uid() or author_id=official_id() or campus_id=my_campus()
    or exists (select 1 from follows f where f.follower_id=auth.uid() and f.followee_id=author_id)));

-- Only staff may post as the official account.
create policy "official posts staff only" on posts as restrictive for insert with check (author_id is distinct from official_id() or is_staff());
create policy "official stories staff only" on stories as restrictive for insert with check (author_id is distinct from official_id() or is_staff());
