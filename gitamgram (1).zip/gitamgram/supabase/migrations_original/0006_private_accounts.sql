-- Private accounts, follow requests, followers/following lists and mutual friends.
alter table profiles add column if not exists is_private boolean not null default false;  -- replaces is_private from 0001 if present

create table if not exists follow_requests (
  requester_id uuid references profiles on delete cascade,
  target_id uuid references profiles on delete cascade,
  created_at timestamptz default now(),
  primary key (requester_id, target_id), check (requester_id <> target_id)
);
alter table follow_requests enable row level security;
create policy "req parties read" on follow_requests for select using (requester_id=auth.uid() or target_id=auth.uid());
create policy "req create" on follow_requests for insert with check (requester_id=auth.uid() and is_verified()
  and exists (select 1 from profiles t where t.id=target_id and t.is_private));
create policy "req cancel or decline" on follow_requests for delete using (requester_id=auth.uid() or target_id=auth.uid());

create or replace function i_follow(target uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from follows where follower_id=auth.uid() and followee_id=target) $$;

-- Following a public account is instant; a private account needs an accepted request.
drop policy if exists "follows insert own" on follows;
create policy "follows insert own" on follows for insert with check (
  follower_id=auth.uid() and exists (select 1 from profiles t where t.id=followee_id and not t.is_private));

-- The owner accepts a request: moves it into follows.
create or replace function accept_follow_request(requester uuid) returns void language plpgsql security definer set search_path=public as $$
begin
  delete from follow_requests where requester_id=requester and target_id=auth.uid();
  if found then insert into follows(follower_id,followee_id) values (requester,auth.uid()) on conflict do nothing; end if;
end $$;
-- Making an account public approves pending requests.
create or replace function approve_all_on_public() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if old.is_private and not new.is_private then
    insert into follows(follower_id,followee_id) select requester_id,new.id from follow_requests where target_id=new.id on conflict do nothing;
    delete from follow_requests where target_id=new.id;
  end if; return new;
end $$;
drop trigger if exists trg_approve_all on profiles;
create trigger trg_approve_all after update of is_private on profiles for each row execute function approve_all_on_public();

-- Posts, reels (posts.is_reel) and stories of a private account: only the owner and accepted followers (staff + official unaffected).
drop policy if exists "posts read" on posts;
create policy "posts read" on posts for select using (
  is_verified() and (
    author_id = official_id() or author_id=auth.uid()
    or (not exists (select 1 from blocks b where (b.blocker_id=auth.uid() and b.blocked_id=author_id) or (b.blocker_id=author_id and b.blocked_id=auth.uid()))
        and (not exists (select 1 from profiles a where a.id=author_id and a.is_private) or i_follow(author_id))
        and (visibility='all' or (visibility='campus' and campus_id=my_campus())
             or (visibility='followers' and i_follow(author_id))))));
drop policy if exists "stories read" on stories;
create policy "stories read" on stories for select using (
  is_verified() and expires_at>now() and (author_id=auth.uid() or author_id=official_id()
    or ((not exists (select 1 from profiles a where a.id=author_id and a.is_private) or i_follow(author_id))
        and (campus_id=my_campus() or i_follow(author_id)))));

-- Counts stay public, but lists of a private account are hidden from non-followers.
drop policy if exists "follows read" on follows;
create policy "follows read" on follows for select using (
  is_verified() and (follower_id=auth.uid() or followee_id=auth.uid()
    or not exists (select 1 from profiles t where t.id in (follower_id,followee_id) and t.is_private and t.id<>auth.uid())
    or exists (select 1 from follows me where me.follower_id=auth.uid() and me.followee_id in (follows.follower_id,follows.followee_id))));
create or replace function follow_counts(p uuid) returns table(followers bigint, following bigint) language sql stable security definer set search_path=public as
$$ select (select count(*) from follows where followee_id=p), (select count(*) from follows where follower_id=p) $$;

-- Mutual friends: people I follow who also follow the target ("Followed by ...").
create or replace function mutual_friends(target uuid) returns setof profiles language sql stable security definer set search_path=public as $$
  select p.* from profiles p
  where exists (select 1 from follows a where a.follower_id=auth.uid() and a.followee_id=p.id)
    and exists (select 1 from follows b where b.follower_id=p.id and b.followee_id=target)
    and p.id <> target and p.id <> auth.uid()
$$;
