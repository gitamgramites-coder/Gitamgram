-- Multi-photo (carousel) posts: up to 10 photos, in order. posts.media_path stays the cover (first photo).
create table if not exists post_media (
  id uuid primary key default gen_random_uuid(), post_id uuid not null references posts on delete cascade,
  position int not null check (position between 0 and 9), media_path text not null, width int, height int,
  unique (post_id, position));
alter table post_media enable row level security;
create policy "post media read" on post_media for select using (exists (select 1 from posts p where p.id = post_id));   -- inherits the posts policy
create policy "post media owner write" on post_media for all using (exists (select 1 from posts p where p.id = post_id and p.user_id = auth.uid()))
  with check (exists (select 1 from posts p where p.id = post_id and p.user_id = auth.uid()));
