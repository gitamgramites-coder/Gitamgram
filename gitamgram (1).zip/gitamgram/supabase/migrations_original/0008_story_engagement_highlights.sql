-- Story likes + replies, and permanent highlights (snapshots that outlive the 24h story).
create table if not exists story_likes (
  story_id uuid references stories on delete cascade,
  user_id uuid references profiles on delete cascade default auth.uid(),
  created_at timestamptz default now(),
  primary key (story_id, user_id)
);
create table if not exists story_comments (
  id uuid primary key default gen_random_uuid(),
  story_id uuid references stories on delete cascade,
  user_id uuid references profiles on delete cascade default auth.uid(),
  body text not null check (char_length(body) between 1 and 300),
  created_at timestamptz default now()
);
alter table story_likes enable row level security;
alter table story_comments enable row level security;
-- anyone who can see the story can like/reply; only the story owner and the author see replies.
create policy "likes read" on story_likes for select using (user_id = auth.uid() or exists (select 1 from stories s where s.id = story_id and s.author_id = auth.uid()));
create policy "likes add" on story_likes for insert with check (user_id = auth.uid() and exists (select 1 from stories s where s.id = story_id and s.expires_at > now()));
create policy "likes remove" on story_likes for delete using (user_id = auth.uid());
create policy "comments read" on story_comments for select using (user_id = auth.uid() or exists (select 1 from stories s where s.id = story_id and s.author_id = auth.uid()));
create policy "comments add" on story_comments for insert with check (user_id = auth.uid() and exists (select 1 from stories s where s.id = story_id and s.expires_at > now()));

create table if not exists highlights (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles on delete cascade default auth.uid(),
  name text not null check (char_length(name) between 1 and 20),
  created_at timestamptz default now()
);
-- Items are copies (media_url + caption), so a highlight survives story expiry, post deletion or archive.
create table if not exists highlight_items (
  id uuid primary key default gen_random_uuid(),
  highlight_id uuid not null references highlights on delete cascade,
  kind text not null check (kind in ('story','post','reel')),
  media_url text, caption text,
  position int not null default 0,
  created_at timestamptz default now()
);
alter table highlights enable row level security;
alter table highlight_items enable row level security;
create policy "highlights read" on highlights for select using (is_verified() and (owner_id = auth.uid() or not exists (select 1 from profiles p where p.id = owner_id and p.is_private) or i_follow(owner_id)));
create policy "highlights own write" on highlights for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "hl items read" on highlight_items for select using (exists (select 1 from highlights h where h.id = highlight_id));
create policy "hl items own write" on highlight_items for all using (exists (select 1 from highlights h where h.id = highlight_id and h.owner_id = auth.uid())) with check (exists (select 1 from highlights h where h.id = highlight_id and h.owner_id = auth.uid()));
