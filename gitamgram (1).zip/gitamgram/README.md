# GITAMGRAM

## Backend status (Supabase project `gitamgramites`)
**Live:** real sign-up / sign-in / sign-out, email confirmation, password change + reset by email, student-ID verification submission, profiles, and the full database with Row Level Security (posts, stories, comments, clubs, events, groups, messages, help desk, promotions, storage buckets).
**Not wired yet:** the feed, stories, reels, chat, clubs etc. in `public/index.html` still run on in-memory demo data. Use `window.GITAMGRAM_SB` (the Supabase client from `public/backend.js`) to read/write them; every table is already protected by RLS.

- `public/backend.js` - connector (defines `window.GITAMGRAM_API`). Contains only the public publishable key.
- `supabase/migrations/0001-0004` - exactly what is deployed. `supabase/migrations_original/` - the earlier prototype migrations, kept for reference only (they contained bugs and are NOT run).
- Music / Rights Foundry (`rf-music`, `rf-sync`, `music-sync`) and the old `send-code`/`verify-code` edge functions are **not deployed**; email codes now come from Supabase Auth.

### One-time dashboard setup
1. **Auth > Email Templates > Confirm signup**: include the 6-digit code, e.g. `<p>Your GITAMGRAM code is <b>{{ .Token }}</b></p>`.
2. **Auth > Providers > Email**: keep "Confirm email" ON. Under **Auth > SMTP** add custom SMTP (Resend etc.); the built-in sender allows only a few emails per hour.
3. **Auth > URL Configuration**: set Site URL to where the app is hosted and add it to Redirect URLs.
4. **Admin account**: Auth > Users > Add user (`gitamgramites@gmail.com`, tick Auto Confirm), then run in the SQL editor:
   `update profiles set role='super_admin', status='verified', display_name='GITAMGRAM Admin' where id=(select id from auth.users where email='gitamgramites@gmail.com');`
5. Approve students: `select review_verification('<request id>', true);` (the in-app admin queue is not wired to the database yet).

## What is here
- `public/index.html` – installable PWA prototype (feed, stories, reels, explore, create, campus hub, clubs, events, confessions, messages, notifications, profile, settings, verification flow, admin dashboard). Demo data, in-memory state, no backend calls.
- `public/manifest.webmanifest`, `public/sw.js`, `public/icon.svg` – PWA install + offline shell.
- `supabase/migrations/0001_init.sql` – full multi-campus schema with Row Level Security.
- `supabase/migrations/0002_groups.sql` – public/private groups and communities.

## Run the prototype
```
npx serve public
```
Open on your phone and use "Add to Home Screen".
Demo logins: any `@gitam.edu` / `@gitam.in` email; `admin@gitam.edu` opens the admin dashboard. Email code: `123456`.

## Next steps to go live
1. Create a Supabase project, run `0001_init.sql`, create the storage buckets noted at the bottom.
2. Port screens to Next.js (App Router) + Tailwind + shadcn/ui, using `@supabase/ssr`. Route map: `/login /register /verify-email /verification-status /home /explore /create /reels /notifications /messages /campus /clubs /events /u/[username] /settings /admin/*`.
3. Turn on email confirmation, PKCE, restricted redirect URLs, custom SMTP and CAPTCHA.
4. Never ship the service-role key to the browser; do role and verification checks server-side too.
5. Pilot with a small group, then expand per campus.
6. Do not advertise chat as "encrypted" until real E2EE exists.

## Going live: real email codes
1. Create a Resend (or any SMTP/API mail) account and verify your sending domain.
2. `supabase secrets set RESEND_API_KEY=... MAIL_FROM="GITAMGRAM <no-reply@yourdomain.com>"`
3. `supabase db push` (runs migrations 0001–0007) then `supabase functions deploy send-code verify-code`
4. In `public/index.html` set `CONFIG.SUPABASE_URL` and `CONFIG.SUPABASE_ANON_KEY`. The demo "123456" code is then switched off and codes are emailed (10-minute expiry, 5 attempts, 30-second resend limit, hashed in the database).

## 24-hour stories and notes
Stories (`expires_at`) and notes (`created_at`) are only readable for 24 hours. The app also filters them client-side, and an expired story moves into the owner's private Archive.

## Music
Users pick a track (search, For you / Trending / New / Saved) for stories (15 s clip), posts and reels (30 s clip) with an adjustable clip start. Admins add tracks in Admin > Music (upload) and every user is notified. The 12 built-in demo tracks are original synthesized loops, so no copyrighted audio ships with the app.
For real songs you must hold a licence: use a licensed catalogue/API, or the `music-sync` edge function (Jamendo, Creative Commons) which keeps the library filling with new releases automatically. Set CONFIG.SUPABASE_URL so the app loads the `tracks` table (it re-checks every time the music picker opens). Commercial chart music (Spotify, T-Series etc.) cannot be embedded without label agreements.

## GITAMGRAM MUSIC (The Rights Foundry)

Files: `supabase/migrations/0012_rights_foundry_music.sql`, `supabase/functions/rf-music` (secure proxy), `supabase/functions/rf-sync` (scheduled refresh). The PWA calls only `rf-music`; the API key is never in browser code.

1. `supabase db push` (runs 0012).
2. `supabase secrets set RIGHTS_FOUNDRY_API_KEY=<token> CRON_SECRET=<random string>` (optional `RF_SYNC_PAGES`, `RF_VERIFY_BATCH`).
3. `supabase functions deploy rf-music rf-sync`.
4. Schedule `rf-sync` every 6 hours (pg_cron + pg_net, header `x-cron-secret`).
5. In the PWA set `CONFIG.SUPABASE_URL` / `SUPABASE_ANON_KEY` and make sure `S.session.access_token` holds the signed-in user's Supabase JWT (rf-music rejects anonymous calls).
6. Admin > Music > Licence status: tracks stay **preview-only** until an admin confirms the contract allows user-generated content (and enters territories). Server-side this is enforced by `track_attachable()`.

Provider facts (from docs.therightsfoundry.com): Bearer token auth; `GET /v1/tracks`, `POST /v1/tracks/deep-search`, `GET /v1/tracks/{id}`, `GET /v1/taxonomies`, `GET /v1/credits`; preview URLs are signed and expire after 1 hour (we never store them); no artwork field; no language/Indian-regional taxonomy (language tabs use keyword search); WAV masters only through `POST /v1/tracks/{id}/sync` (per-track credits).

## Logo & icons
The GITAMGRAM logo (transparent mark in teal and gold, live two-tone wordmark) is embedded in `src/app.html` (header, sign-in, landing, admin sidebar, official-account avatar, favicon). PWA icons live in `public/` (`icon-192.png`, `icon-512.png`, `maskable-512.png`, `apple-touch-icon.png`, `favicon.png`) and are referenced by `manifest.webmanifest`.

## Passwords (change / forgot)
- Settings → Password → **Change**: user must enter the current password, then a new one (min 8, different, confirmed).
- **Forgot password** (Settings, Change sheet, and the Login page) auto-raises a Help desk ticket (category "Password reset"; duplicates are merged).
- Admin → Helpdesk → **Reset password & reply** generates a temporary password, replies on the ticket and marks it solved. The user reads it from Help desk, or on the login page via "Check ticket status" (ticket number + email), and is forced to set a new password at next sign-in.
- Prototype only: passwords live in session state. For production use Supabase Auth, do the reset in a service-role edge function (`auth.admin.updateUserById`), and prefer emailing a reset link over placing a password in a ticket. See `0018_password_reset_requests.sql`.

## Connecting your backend (no demo accounts)
Demo accounts, demo passwords, the demo code and the hard-coded admin login are removed. The app has no local password store. Define `window.GITAMGRAM_API` in a `<script>` **before** the main app script (or in a file loaded before it):

```js
window.GITAMGRAM_API = {
  login: (email, password) => fetch(...).then(r => /* {role:"student"|"admin"|"super_admin", user:{name,un,campus,...}, mustChangePassword?} */),
  register: ({name,email,phone,campus,password}) => ...,       // optional
  changePassword: (oldPassword, newPassword) => ...,           // reject with Error(message) on failure
  resetPassword: (email, temporaryPassword) => ...,            // admin Helpdesk "Reset password"
  forgotPassword: (email) => ...                               // optional
};
```
Without it, Sign in shows "server is not connected". Admin access must come from `role` returned by your server, and your server must enforce it; never trust the client.
