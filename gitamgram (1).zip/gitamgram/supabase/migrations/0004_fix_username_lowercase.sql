-- Fix: lowercase the email local part BEFORE stripping invalid characters (Ravi.Kumar -> ravi.kumar, not .avi..umar).
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
declare base text; uname text; cid uuid;
begin
  base := regexp_replace(lower(split_part(new.email,'@',1)),'[^a-z0-9._]','.','g');
  if length(base)<3 then base := base||'.user'; end if;
  uname := left(base,24);
  while exists (select 1 from profiles where username=uname) loop uname := left(base,24)||'.'||substr(md5(random()::text),1,4); end loop;
  select id into cid from campuses where slug = coalesce(new.raw_user_meta_data->>'campus','hyd');
  if cid is null then select id into cid from campuses where slug='hyd'; end if;
  insert into profiles (id,username,display_name,campus_id)
  values (new.id, uname, coalesce(nullif(trim(new.raw_user_meta_data->>'name'),''), initcap(replace(base,'.',' '))), cid);
  return new;
end $$;
revoke execute on function handle_new_user() from public, anon, authenticated;
