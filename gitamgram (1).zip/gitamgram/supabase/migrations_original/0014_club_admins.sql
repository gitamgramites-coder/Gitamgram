-- Club admin = clubs.owner_id. GITAMGRAM staff create clubs (or approve student proposals) and assign the admin by username.
-- The club admin approves join requests for private clubs and edits the club page.
alter table clubs add column if not exists privacy text not null default 'public' check (privacy in ('public','private'));
create table if not exists club_join_requests (club_id uuid references clubs on delete cascade, user_id uuid references profiles on delete cascade default auth.uid(), created_at timestamptz default now(), primary key (club_id, user_id));
alter table club_join_requests enable row level security;
create or replace function is_club_admin(c uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from clubs where id=c and owner_id=auth.uid()) $$;
create or replace function assign_club_admin(club uuid, uname text) returns void language plpgsql security definer set search_path=public as $$
declare pid uuid; begin
  if not is_staff() then raise exception 'staff only'; end if;
  select id into pid from profiles where username = lower(regexp_replace(uname,'^@',''));
  if pid is null then raise exception 'No user with that username'; end if;
  update clubs set owner_id = pid where id = club;
end $$;
create policy "club req own/admin read" on club_join_requests for select using (user_id=auth.uid() or is_club_admin(club_id) or is_staff());
create policy "club req create" on club_join_requests for insert with check (user_id=auth.uid() and is_verified());
create policy "club req resolve" on club_join_requests for delete using (user_id=auth.uid() or is_club_admin(club_id) or is_staff());
-- Private clubs: the admin (or staff) adds approved members; public clubs: anyone verified joins themselves.
drop policy if exists "club members" on club_members;
create policy "club members read" on club_members for select using (user_id=auth.uid() or is_club_admin(club_id) or is_staff() or exists (select 1 from clubs c where c.id=club_id and c.privacy='public'));
create policy "club join" on club_members for insert with check ((user_id=auth.uid() and exists (select 1 from clubs c where c.id=club_id and c.privacy='public') and is_verified()) or is_club_admin(club_id) or is_staff());
create policy "club leave" on club_members for delete using (user_id=auth.uid() or is_club_admin(club_id) or is_staff());
