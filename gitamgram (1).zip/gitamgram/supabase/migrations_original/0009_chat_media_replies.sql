-- Chat: photo/video attachments, replies to a specific message, and delete-for-everyone.
alter table messages add column if not exists media_url text;
alter table messages add column if not exists media_kind text check (media_kind in ('image','video'));
alter table messages add column if not exists reply_to uuid references messages on delete set null;
alter table messages add column if not exists deleted_at timestamptz;
-- Only the sender may delete, and deleting blanks the content instead of removing the row (keeps reply quotes consistent).
create or replace function delete_message(mid uuid) returns void language sql security definer set search_path=public as $$
  update messages set body = '', media_url = null, media_kind = null, deleted_at = now() where id = mid and sender_id = auth.uid()
$$;
-- Storage bucket for chat media (private; access through signed URLs)
insert into storage.buckets (id, name, public) values ('chat-media','chat-media',false) on conflict do nothing;
create policy "chat media upload" on storage.objects for insert to authenticated with check (bucket_id='chat-media' and (storage.foldername(name))[1] = auth.uid()::text);
