-- Password reset via Help desk. The app auto-raises a ticket (category 'Password reset');
-- an admin issues a temporary password and replies on the ticket; the user must change it at next sign-in.
-- NOTE: with real Supabase Auth, do the reset server-side (service-role edge function calling
-- auth.admin.updateUserById) and never store or return plaintext passwords from tables.
alter table if exists public.tickets add column if not exists email text;
alter table if exists public.profiles add column if not exists must_change_password boolean not null default false;
