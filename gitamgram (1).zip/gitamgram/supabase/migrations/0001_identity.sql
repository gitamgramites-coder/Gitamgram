-- GITAMGRAM 0001: identity, auth hooks, verification, follows. Final-state, consolidated from the original 0001/0003-0006/0018.
create extension if not exists pgcrypto;
create type user_role as enum ('student','club','faculty','alumni','moderator','super_admin');
create type verif_status as enum ('email_pending','verification_pending','under_review','verified','rejected','suspended');
create type visibility as enum ('campus','all','followers');

create table campuses (id uuid primary key default gen_random_uuid(), slug text unique not null, name text not null);
create table departments (id uuid primary key default gen_random_uuid(), campus_id uuid references campuses not null, name text not null);
insert into campuses (slug,name) values ('blr','Bengaluru'),('hyd','Hyderabad'),('vsp','Visakhapatnam');

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  username text unique not null check (username ~ '^[a-z0-9._]{3,30}$'),
  display_name text not null, bio text default '', avatar_url text,
  campus_id uuid references campuses not null, department_id uuid references departments, department text,
  academic_year text, role user_role not null default 'student',
  status verif_status not null default 'email_pending',
  is_private boolean not null default false, has_badge boolean not null default false,
  is_official boolean not null default false, must_change_password boolean not null default false,
  created_at timestamptz default now()
);
create unique index one_official on profiles (is_official) where is_official;

create table verification_requests (
  id uuid primary key default gen_random_uuid(), user_id uuid references profiles on delete cascade not null,
  student_id text not null, document_path text, status verif_status not null default 'verification_pending',
  reviewer_id uuid references profiles, reviewed_at timestamptz, note text, created_at timestamptz default now()
);
create table student_records (
  user_id uuid primary key references profiles on delete cascade,
  campus_id uuid references campuses not null,
  sn bigint generated always as identity,
  phone text not null check (phone ~ '^\+91 ?[6-9][0-9]{4} ?[0-9]{5}$'),
  student_id text not null check (student_id ~ '^[A-Za-z0-9][A-Za-z0-9/-]{3,19}$'),
  email text, created_at timestamptz default now(),
  unique (campus_id, student_id)
);
create table badge_requests (
  id uuid primary key default gen_random_uuid(), user_id uuid references profiles on delete cascade not null,
  category text not null, reason text not null check (char_length(reason) between 15 and 300), proof_link text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  note text, reviewer_id uuid references profiles, reviewed_at timestamptz, created_at timestamptz default now()
);
create table follows (follower_id uuid references profiles on delete cascade, followee_id uuid references profiles on delete cascade, primary key (follower_id,followee_id));
create table follow_requests (requester_id uuid references profiles on delete cascade, target_id uuid references profiles on delete cascade, created_at timestamptz default now(), primary key (requester_id,target_id), check (requester_id <> target_id));
create table blocks (blocker_id uuid references profiles on delete cascade, blocked_id uuid references profiles on delete cascade, primary key (blocker_id,blocked_id));
create table audit_logs (id bigserial primary key, actor_id uuid references profiles, action text not null, detail jsonb, created_at timestamptz default now());

-- Helpers (SECURITY DEFINER so RLS policies never recurse)
create function is_staff() returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from profiles where id=auth.uid() and role in ('moderator','super_admin') and status='verified') $$;
create function is_verified() returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from profiles where id=auth.uid() and status='verified') $$;
create function my_campus() returns uuid language sql stable security definer set search_path=public as
$$ select campus_id from profiles where id=auth.uid() $$;
create function official_id() returns uuid language sql stable security definer set search_path=public as
$$ select id from profiles where is_official limit 1 $$;
create function i_follow(target uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from follows where follower_id=auth.uid() and followee_id=target) $$;
create function follows_user(a uuid, b uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from follows where follower_id=a and followee_id=b) $$;
-- Visibility of a follow edge (replaces the self-referencing policy that caused infinite recursion)
create function follows_visible(a uuid, b uuid) returns boolean language sql stable security definer set search_path=public as
$$ select a=auth.uid() or b=auth.uid()
   or not exists (select 1 from profiles t where t.id in (a,b) and t.is_private)
   or exists (select 1 from follows me where me.follower_id=auth.uid() and me.followee_id in (a,b)) $$;

-- Only staff may change role/status/badge/official flags. No JWT (SQL editor, service role) = trusted.
create function protect_profile() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is not null and not is_staff() and (new.role<>old.role or new.status<>old.status or new.has_badge<>old.has_badge
     or new.is_official<>old.is_official or new.must_change_password<>old.must_change_password or new.id<>old.id) then
    raise exception 'role/status/badge can only be changed by staff'; end if;
  return new;
end $$;
create trigger trg_protect_profile before update on profiles for each row execute function protect_profile();

-- Only GITAM addresses (and the platform admin mailbox) may create an account.
create function enforce_gitam_email() returns trigger language plpgsql security definer set search_path='' as $$
begin
  if lower(new.email) !~ '^[^@\s]+@([a-z0-9-]+\.)*gitam\.(edu|in)$' and lower(new.email) <> 'gitamgramites@gmail.com' then
    raise exception 'Only GITAM university emails (@gitam.edu / @gitam.in) can register.'; end if;
  return new;
end $$;
create trigger trg_enforce_gitam_email before insert on auth.users for each row execute function enforce_gitam_email();

-- Every new auth user gets a profile (name/campus come from signUp options.data).
create function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
declare base text; uname text; cid uuid;
begin
  base := lower(regexp_replace(split_part(new.email,'@',1),'[^a-z0-9._]','.','g'));
  if length(base)<3 then base := base||'.user'; end if;
  uname := left(base,24);
  while exists (select 1 from profiles where username=uname) loop uname := left(base,24)||'.'||substr(md5(random()::text),1,4); end loop;
  select id into cid from campuses where slug = coalesce(new.raw_user_meta_data->>'campus','hyd');
  if cid is null then select id into cid from campuses where slug='hyd'; end if;
  insert into profiles (id,username,display_name,campus_id)
  values (new.id, uname, coalesce(nullif(trim(new.raw_user_meta_data->>'name'),''), initcap(replace(base,'.',' '))), cid);
  return new;
end $$;
create trigger trg_handle_new_user after insert on auth.users for each row execute function handle_new_user();

create function student_record_email() returns trigger language plpgsql security definer set search_path=public as $$
begin new.email := (select email from auth.users where id=new.user_id); return new; end $$;
create trigger trg_student_record_email before insert on student_records for each row execute function student_record_email();

-- Every new profile follows the official account
create function auto_follow_official() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if not new.is_official and official_id() is not null then
    insert into follows(follower_id,followee_id) values (new.id, official_id()) on conflict do nothing; end if;
  return new;
end $$;
create trigger trg_auto_follow_official after insert on profiles for each row execute function auto_follow_official();

create function approve_all_on_public() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if old.is_private and not new.is_private then
    insert into follows(follower_id,followee_id) select requester_id,new.id from follow_requests where target_id=new.id on conflict do nothing;
    delete from follow_requests where target_id=new.id;
  end if; return new;
end $$;
create trigger trg_approve_all after update of is_private on profiles for each row execute function approve_all_on_public();

-- RPCs
-- Student submits ID + phone after confirming their email. Email must be confirmed server-side.
create function submit_verification(p_student_id text, p_phone text, p_department text default null, p_year text default null) returns void
language plpgsql security definer set search_path=public as $$
declare me profiles; begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if not exists (select 1 from auth.users where id=auth.uid() and email_confirmed_at is not null) then raise exception 'Confirm your email first'; end if;
  select * into me from profiles where id=auth.uid();
  if me.status in ('verified','suspended') then raise exception 'Already %', me.status; end if;
  insert into student_records (user_id,campus_id,phone,student_id) values (auth.uid(), me.campus_id, p_phone, upper(trim(p_student_id)))
    on conflict (user_id) do update set phone=excluded.phone, student_id=excluded.student_id;
  delete from verification_requests where user_id=auth.uid() and status<>'verified';
  insert into verification_requests (user_id,student_id) values (auth.uid(), upper(trim(p_student_id)));
  update profiles set status='verification_pending', department=coalesce(p_department,department), academic_year=coalesce(p_year,academic_year) where id=auth.uid();
end $$;

create function review_verification(req uuid, approve boolean, reviewer_note text default null) returns void
language plpgsql security definer set search_path=public as $$
declare r verification_requests; begin
  if not is_staff() then raise exception 'staff only'; end if;
  update verification_requests set status=case when approve then 'verified' else 'rejected' end, note=reviewer_note, reviewer_id=auth.uid(), reviewed_at=now() where id=req returning * into r;
  update profiles set status=case when approve then 'verified'::verif_status else 'rejected'::verif_status end where id=r.user_id;
  insert into audit_logs(actor_id,action,detail) values (auth.uid(), case when approve then 'verification_approved' else 'verification_rejected' end, jsonb_build_object('user',r.user_id,'request',req));
end $$;

create function review_badge(req uuid, approve boolean, reviewer_note text default null) returns void
language plpgsql security definer set search_path=public as $$
declare r badge_requests; begin
  if not is_staff() then raise exception 'staff only'; end if;
  update badge_requests set status=case when approve then 'approved' else 'rejected' end, note=reviewer_note, reviewer_id=auth.uid(), reviewed_at=now() where id=req returning * into r;
  update profiles set has_badge=approve where id=r.user_id;
  insert into audit_logs(actor_id,action,detail) values (auth.uid(), case when approve then 'badge_granted' else 'badge_declined' end, jsonb_build_object('user',r.user_id,'request',req));
end $$;

create function accept_follow_request(requester uuid) returns void language plpgsql security definer set search_path=public as $$
begin
  delete from follow_requests where requester_id=requester and target_id=auth.uid();
  if found then insert into follows(follower_id,followee_id) values (requester,auth.uid()) on conflict do nothing; end if;
end $$;
create function follow_counts(p uuid) returns table(followers bigint, following bigint) language sql stable security definer set search_path=public as
$$ select (select count(*) from follows where followee_id=p), (select count(*) from follows where follower_id=p) $$;
create function mutual_friends(target uuid) returns setof profiles language sql stable security definer set search_path=public as $$
  select p.* from profiles p where is_verified()
    and exists (select 1 from follows a where a.follower_id=auth.uid() and a.followee_id=p.id)
    and exists (select 1 from follows b where b.follower_id=p.id and b.followee_id=target)
    and p.id<>target and p.id<>auth.uid() $$;

-- RLS
alter table campuses enable row level security; alter table departments enable row level security; alter table profiles enable row level security;
alter table verification_requests enable row level security; alter table student_records enable row level security; alter table badge_requests enable row level security;
alter table follows enable row level security; alter table follow_requests enable row level security; alter table blocks enable row level security; alter table audit_logs enable row level security;

create policy "campuses read" on campuses for select to authenticated using (true);
create policy "departments read" on departments for select to authenticated using (true);
create policy "staff manage campuses" on campuses for all to authenticated using (is_staff()) with check (is_staff());
create policy "profiles read" on profiles for select to authenticated using (is_verified() or id=auth.uid());
create policy "profiles update self" on profiles for update to authenticated using (id=auth.uid() or is_staff());
create policy "profiles delete self" on profiles for delete to authenticated using (id=auth.uid());
create policy "verif own" on verification_requests for select to authenticated using (user_id=auth.uid() or is_staff());
create policy "record own" on student_records for select to authenticated using (user_id=auth.uid() or is_staff());
create policy "badge req read" on badge_requests for select to authenticated using (user_id=auth.uid() or is_staff());
create policy "badge req create" on badge_requests for insert to authenticated with check (user_id=auth.uid() and status='pending' and is_verified());
create policy "req parties read" on follow_requests for select to authenticated using (requester_id=auth.uid() or target_id=auth.uid());
create policy "req create" on follow_requests for insert to authenticated with check (requester_id=auth.uid() and is_verified() and exists (select 1 from profiles t where t.id=target_id and t.is_private));
create policy "req cancel or decline" on follow_requests for delete to authenticated using (requester_id=auth.uid() or target_id=auth.uid());
create policy "follows read" on follows for select to authenticated using (is_verified() and follows_visible(follower_id,followee_id));
create policy "follows insert own" on follows for insert to authenticated with check (follower_id=auth.uid() and is_verified() and exists (select 1 from profiles t where t.id=followee_id and not t.is_private));
create policy "follows delete own except official" on follows for delete to authenticated using (follower_id=auth.uid() and followee_id is distinct from official_id());
create policy "blocks own" on blocks for all to authenticated using (blocker_id=auth.uid()) with check (blocker_id=auth.uid());
create policy "audit staff read" on audit_logs for select to authenticated using (is_staff());
