-- GITAMGRAM initial schema: multi-campus, RLS on from day one.
create extension if not exists pgcrypto;

create type user_role as enum ('student','club','faculty','alumni','moderator','super_admin');
create type verif_status as enum ('email_pending','verification_pending','under_review','verified','rejected','suspended');
create type visibility as enum ('campus','all','followers');

-- 01 Identity
create table campuses (id uuid primary key default gen_random_uuid(), slug text unique not null, name text not null);
create table departments (id uuid primary key default gen_random_uuid(), campus_id uuid references campuses not null, name text not null);
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  username text unique not null check (username ~ '^[a-z0-9._]{3,30}$'),
  display_name text not null, bio text default '', avatar_url text,
  campus_id uuid references campuses not null, department_id uuid references departments,
  academic_year text, role user_role not null default 'student',
  status verif_status not null default 'email_pending',
  is_private boolean not null default false, created_at timestamptz default now()
);
create table verification_requests (
  id uuid primary key default gen_random_uuid(), user_id uuid references profiles on delete cascade not null,
  student_id text not null, document_path text, status verif_status not null default 'verification_pending',
  reviewer_id uuid references profiles, reviewed_at timestamptz, note text, created_at timestamptz default now()
);

-- 02 Social
create table posts (id uuid primary key default gen_random_uuid(), author_id uuid references profiles on delete cascade not null, campus_id uuid references campuses not null,
  caption text not null check (char_length(caption) <= 2200), visibility visibility not null default 'campus', is_reel boolean default false, music text, created_at timestamptz default now());
create table post_media (id uuid primary key default gen_random_uuid(), post_id uuid references posts on delete cascade not null, path text not null, kind text check (kind in ('image','video')));
create table comments (id uuid primary key default gen_random_uuid(), post_id uuid references posts on delete cascade not null, author_id uuid references profiles on delete cascade not null, body text not null check (char_length(body) <= 500), created_at timestamptz default now());
create table likes (post_id uuid references posts on delete cascade, user_id uuid references profiles on delete cascade, primary key (post_id,user_id));
create table saves (post_id uuid references posts on delete cascade, user_id uuid references profiles on delete cascade, primary key (post_id,user_id));
create table follows (follower_id uuid references profiles on delete cascade, followee_id uuid references profiles on delete cascade, primary key (follower_id,followee_id));

-- 03 Stories
create table stories (id uuid primary key default gen_random_uuid(), author_id uuid references profiles on delete cascade not null, campus_id uuid references campuses not null, media_path text, text text, expires_at timestamptz not null default now() + interval '24 hours');
create table story_views (story_id uuid references stories on delete cascade, viewer_id uuid references profiles on delete cascade, primary key (story_id,viewer_id));

-- 04 Communities, 05 Events
create table clubs (id uuid primary key default gen_random_uuid(), campus_id uuid references campuses not null, slug text unique not null, name text not null, about text, category text, is_verified boolean default false, owner_id uuid references profiles);
create table club_members (club_id uuid references clubs on delete cascade, user_id uuid references profiles on delete cascade, primary key (club_id,user_id));
create table events (id uuid primary key default gen_random_uuid(), club_id uuid references clubs, campus_id uuid references campuses not null, title text not null, starts_at timestamptz not null, place text, capacity int);
create table event_attendees (event_id uuid references events on delete cascade, user_id uuid references profiles on delete cascade, remind boolean default false, primary key (event_id,user_id));

-- 06 Messaging
create table conversations (id uuid primary key default gen_random_uuid(), is_group boolean default false, created_at timestamptz default now());
create table conversation_members (conversation_id uuid references conversations on delete cascade, user_id uuid references profiles on delete cascade, accepted boolean default false, primary key (conversation_id,user_id));
create table messages (id uuid primary key default gen_random_uuid(), conversation_id uuid references conversations on delete cascade not null, sender_id uuid references profiles not null, body text not null check (char_length(body) <= 2000), created_at timestamptz default now());
create table blocks (blocker_id uuid references profiles on delete cascade, blocked_id uuid references profiles on delete cascade, primary key (blocker_id,blocked_id));

-- 07 Notifications, confessions
create table notifications (id uuid primary key default gen_random_uuid(), user_id uuid references profiles on delete cascade not null, actor_id uuid references profiles, kind text not null, ref_id uuid, read boolean default false, created_at timestamptz default now());
create table device_tokens (user_id uuid references profiles on delete cascade, token text primary key);
create table confessions (id uuid primary key default gen_random_uuid(), campus_id uuid references campuses not null, body text not null check (char_length(body) <= 280), status text not null default 'pending' check (status in ('pending','published','rejected')), created_at timestamptz default now()); -- no author column: anonymous by design

-- 08 Moderation
create table reports (id uuid primary key default gen_random_uuid(), reporter_id uuid references profiles, target_type text not null, target_id uuid not null, reason text not null, status text default 'open', created_at timestamptz default now());
create table moderation_actions (id uuid primary key default gen_random_uuid(), moderator_id uuid references profiles not null, report_id uuid references reports, action text not null, created_at timestamptz default now());
create table audit_logs (id bigserial primary key, actor_id uuid references profiles, action text not null, detail jsonb, created_at timestamptz default now());

-- Helpers (SECURITY DEFINER so policies cannot be bypassed by editing own profile)
create or replace function is_staff() returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from profiles where id = auth.uid() and role in ('moderator','super_admin') and status='verified') $$;
create or replace function is_verified() returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from profiles where id = auth.uid() and status='verified') $$;
create or replace function my_campus() returns uuid language sql stable security definer set search_path=public as
$$ select campus_id from profiles where id = auth.uid() $$;
create or replace function in_conversation(c uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from conversation_members where conversation_id=c and user_id=auth.uid()) $$;

-- Block users from escalating their own role/status
create or replace function protect_profile() returns trigger language plpgsql security definer as $$
begin
  if not is_staff() and (new.role<>old.role or new.status<>old.status) then
    raise exception 'role/status can only be changed by staff';
  end if; return new;
end $$;
create trigger trg_protect_profile before update on profiles for each row execute function protect_profile();

-- Row Level Security: enable everywhere
do $$ declare t text; begin
  for t in select tablename from pg_tables where schemaname='public' loop
    execute format('alter table public.%I enable row level security', t);
  end loop; end $$;

-- Reference data
create policy "campuses readable" on campuses for select using (true);
create policy "departments readable" on departments for select using (true);
create policy "staff manage campuses" on campuses for all using (is_staff()) with check (is_staff());

-- Profiles: verified members can read; users edit only themselves
create policy "profiles read" on profiles for select using (is_verified() or id=auth.uid());
create policy "profiles insert self" on profiles for insert with check (id=auth.uid() and role='student' and status='email_pending');
create policy "profiles update self" on profiles for update using (id=auth.uid() or is_staff());
create policy "profiles delete self" on profiles for delete using (id=auth.uid());

-- Verification documents: owner + staff only
create policy "verif own" on verification_requests for select using (user_id=auth.uid() or is_staff());
create policy "verif create" on verification_requests for insert with check (user_id=auth.uid());
create policy "verif staff review" on verification_requests for update using (is_staff());

-- Posts: by visibility
create policy "posts read" on posts for select using (
  is_verified() and not exists (select 1 from blocks b where (b.blocker_id=auth.uid() and b.blocked_id=author_id) or (b.blocker_id=author_id and b.blocked_id=auth.uid()))
  and (author_id=auth.uid() or visibility='all' or (visibility='campus' and campus_id=my_campus())
       or (visibility='followers' and exists (select 1 from follows f where f.follower_id=auth.uid() and f.followee_id=author_id))));
create policy "posts write" on posts for insert with check (author_id=auth.uid() and is_verified());
create policy "posts edit own" on posts for update using (author_id=auth.uid());
create policy "posts delete own or staff" on posts for delete using (author_id=auth.uid() or is_staff());

create policy "media follows post" on post_media for select using (exists (select 1 from posts p where p.id=post_id));
create policy "media insert own" on post_media for insert with check (exists (select 1 from posts p where p.id=post_id and p.author_id=auth.uid()));
create policy "likes read" on likes for select using (exists (select 1 from posts p where p.id=post_id));
create policy "likes own" on likes for all using (user_id=auth.uid()) with check (user_id=auth.uid() and exists (select 1 from posts p where p.id=post_id));
create policy "saves own" on saves for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "comments read" on comments for select using (exists (select 1 from posts p where p.id=post_id));
create policy "comments write" on comments for insert with check (author_id=auth.uid() and exists (select 1 from posts p where p.id=post_id));
create policy "comments delete" on comments for delete using (author_id=auth.uid() or is_staff());
create policy "follows read" on follows for select using (is_verified());
create policy "follows own" on follows for all using (follower_id=auth.uid()) with check (follower_id=auth.uid());

-- Stories: 24h window
create policy "stories read" on stories for select using (is_verified() and expires_at>now() and (author_id=auth.uid() or campus_id=my_campus() or exists (select 1 from follows f where f.follower_id=auth.uid() and f.followee_id=author_id)));
create policy "stories write" on stories for insert with check (author_id=auth.uid() and is_verified());
create policy "story views" on story_views for all using (viewer_id=auth.uid()) with check (viewer_id=auth.uid());

-- Clubs & events
create policy "clubs read" on clubs for select using (is_verified());
create policy "clubs create" on clubs for insert with check (owner_id=auth.uid() and is_verified() and is_verified=false);
create policy "clubs staff" on clubs for update using (is_staff() or owner_id=auth.uid());
create policy "club members" on club_members for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "events read" on events for select using (is_verified());
create policy "events staff/owner write" on events for all using (is_staff() or exists (select 1 from clubs c where c.id=club_id and c.owner_id=auth.uid())) with check (is_staff() or exists (select 1 from clubs c where c.id=club_id and c.owner_id=auth.uid()));
create policy "attendees own" on event_attendees for all using (user_id=auth.uid()) with check (user_id=auth.uid());

-- Messages: participants only
create policy "conv member read" on conversations for select using (in_conversation(id));
create policy "conv create" on conversations for insert with check (is_verified());
create policy "members read" on conversation_members for select using (in_conversation(conversation_id));
create policy "members self update" on conversation_members for update using (user_id=auth.uid());
create policy "messages read" on messages for select using (in_conversation(conversation_id));
create policy "messages send" on messages for insert with check (sender_id=auth.uid() and in_conversation(conversation_id));
create policy "blocks own" on blocks for all using (blocker_id=auth.uid()) with check (blocker_id=auth.uid());

-- Notifications: recipient only
create policy "notif own" on notifications for select using (user_id=auth.uid());
create policy "notif mark read" on notifications for update using (user_id=auth.uid());
create policy "tokens own" on device_tokens for all using (user_id=auth.uid()) with check (user_id=auth.uid());

-- Confessions: public only when moderator-published; submit through insert, never see author
create policy "confessions published" on confessions for select using ((is_verified() and status='published') or is_staff());
create policy "confessions submit" on confessions for insert with check (is_verified() and status='pending');
create policy "confessions moderate" on confessions for update using (is_staff());

-- Moderation & admin
create policy "reports create" on reports for insert with check (reporter_id=auth.uid());
create policy "reports staff" on reports for select using (is_staff());
create policy "reports staff update" on reports for update using (is_staff());
create policy "mod actions staff" on moderation_actions for all using (is_staff()) with check (is_staff());
create policy "audit staff read" on audit_logs for select using (is_staff());
create policy "audit staff write" on audit_logs for insert with check (is_staff());

-- Storage buckets (create in dashboard or here): avatars (public), media (authenticated read), verification-docs (private; owner + staff)
-- insert into storage.buckets (id,name,public) values ('avatars','avatars',true),('media','media',false),('verification-docs','verification-docs',false);

create index on posts (campus_id, created_at desc);
create index on posts (author_id, created_at desc);
create index on messages (conversation_id, created_at);
create index on notifications (user_id, read, created_at desc);
