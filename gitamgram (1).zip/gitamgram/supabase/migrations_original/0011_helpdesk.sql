-- Help desk tickets. The username is copied from the profile by a trigger, so users can never type or change it.
create type ticket_status as enum ('not_started','processing','solved');
create table if not exists tickets (
  id bigint generated always as identity primary key,
  code text generated always as ('T-' || (1000 + id)) stored,
  user_id uuid not null references profiles on delete cascade,
  username text not null,
  category text not null,
  subject text not null check (char_length(subject) between 3 and 80),
  description text not null check (char_length(description) between 5 and 800),
  status ticket_status not null default 'not_started',
  admin_response text,
  handled_by uuid references profiles,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table tickets enable row level security;
create policy "tickets read own or staff" on tickets for select using (user_id = auth.uid() or is_staff());
create policy "tickets create own" on tickets for insert with check (user_id = auth.uid());
-- users cannot update tickets at all; staff can change status and respond
create policy "tickets staff update" on tickets for update using (is_staff()) with check (is_staff());

create or replace function ticket_before_insert() returns trigger language plpgsql security definer set search_path=public as $$
begin
  new.user_id := auth.uid();
  new.username := (select username from profiles where id = auth.uid());   -- forced from the profile
  new.status := 'not_started'; new.admin_response := null; new.handled_by := null;
  return new;
end $$;
create trigger trg_ticket_ins before insert on tickets for each row execute function ticket_before_insert();

create or replace function ticket_before_update() returns trigger language plpgsql security definer set search_path=public as $$
begin
  new.username := old.username; new.user_id := old.user_id; new.subject := old.subject; new.description := old.description;  -- immutable
  new.handled_by := auth.uid(); new.updated_at := now();
  return new;
end $$;
create trigger trg_ticket_upd before update on tickets for each row execute function ticket_before_update();

-- Notify the user when staff change the status or reply
create or replace function ticket_notify() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.status is distinct from old.status or new.admin_response is distinct from old.admin_response then
    insert into notifications(user_id, actor_id, kind, body)
    values (new.user_id, official_id(), 'ticket', 'updated your ticket ' || new.code || ': ' || replace(new.status::text,'_',' '));
  end if;
  return new;
end $$;
create trigger trg_ticket_notify after update on tickets for each row execute function ticket_notify();
