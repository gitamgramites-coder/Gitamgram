-- GITAMGRAM MUSIC: The Rights Foundry catalogue, favourites, usage, licences, original sounds, takedowns.
-- Provider secrets (RIGHTS_FOUNDRY_API_KEY) live ONLY in Edge Function secrets, never in these tables.
-- Provider audio is NOT stored: we keep track ids + metadata; preview URLs are signed (1h) and re-fetched via the rf-music function.

create table if not exists music_licenses (
  id uuid primary key default gen_random_uuid(),
  provider text not null default 'rightsfoundry',
  kind text not null check (kind in ('preview','sync','export_sync','original')),
  -- Admin must tick these after reading the provider contract. Nothing is attachable to content until true.
  allow_ugc_attach boolean not null default false,   -- may users attach this to posts/reels/stories?
  allow_social_distribution boolean not null default false,
  allow_monetised boolean not null default false,
  territories text[] not null default '{}',           -- empty = not confirmed; use ISO codes e.g. {'IN'} or {'WORLD'}
  max_clip_seconds int,                              -- provider/licence limit on clip length, null = unconfirmed
  expires_at timestamptz,
  notes text,
  confirmed_by uuid references profiles, confirmed_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (provider, kind)
);
insert into music_licenses (provider, kind) values ('rightsfoundry','preview'),('rightsfoundry','sync'),('rightsfoundry','export_sync'),('gitamgram','original')
  on conflict do nothing;

create table if not exists music_artists (
  id uuid primary key default gen_random_uuid(), name text not null unique,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists music_albums (
  id uuid primary key default gen_random_uuid(), title text not null, artist_id uuid references music_artists,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique (title, artist_id));
create table if not exists music_genres (
  id uuid primary key default gen_random_uuid(), value text not null unique, kind text not null default 'genre', track_count int default 0,
  updated_at timestamptz not null default now());

create table if not exists music_tracks (
  id uuid primary key default gen_random_uuid(),
  provider text not null default 'rightsfoundry',
  provider_track_id text not null,                   -- Track.id from the provider
  title text not null, artist_id uuid references music_artists, album_id uuid references music_albums,
  duration int,                                      -- seconds
  bpm int, musical_key text, vocals text, explicit boolean default false,
  genres text[] default '{}', moods text[] default '{}', instruments text[] default '{}',
  first_published date, release_date date,
  has_alternatives boolean default false,
  license_id uuid references music_licenses,
  status text not null default 'active' check (status in ('active','restricted','withdrawn')),
  restricted_reason text,
  is_new boolean not null default false,
  last_seen_at timestamptz not null default now(),   -- sync marks tracks missing from the provider as withdrawn
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (provider, provider_track_id)
);
create index if not exists music_tracks_new on music_tracks (first_published desc);
create index if not exists music_tracks_genres on music_tracks using gin (genres);

create table if not exists music_favorites (
  user_id uuid references profiles on delete cascade default auth.uid(),
  track_id uuid references music_tracks on delete cascade, created_at timestamptz default now(),
  primary key (user_id, track_id));

create table if not exists music_usage (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles default auth.uid(),
  track_id uuid references music_tracks, sound_id uuid,
  surface text not null check (surface in ('post','reel','story','preview')),
  content_id uuid, clip_start int default 0, clip_seconds int,
  created_at timestamptz not null default now());
create index if not exists music_usage_track on music_usage (track_id);

create table if not exists original_sounds (
  id uuid primary key default gen_random_uuid(), owner_id uuid not null references profiles default auth.uid(),
  title text not null check (char_length(title) between 1 and 80), description text check (char_length(description) <= 300),
  audio_path text not null,                           -- private storage path in bucket 'original-sounds'
  duration int check (duration between 1 and 90), size_bytes int check (size_bytes <= 10485760),
  mime text not null check (mime in ('audio/mpeg','audio/mp4','audio/aac','audio/wav','audio/ogg')),
  status text not null default 'pending' check (status in ('pending','approved','rejected','removed')),
  confirmed_own_rights boolean not null default false check (confirmed_own_rights),  -- uploader attests rights
  moderated_by uuid references profiles, moderated_at timestamptz,
  uses int not null default 0,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now());

create table if not exists music_reports (          -- copyright reports / takedown requests
  id uuid primary key default gen_random_uuid(), reporter_id uuid references profiles default auth.uid(),
  track_id uuid references music_tracks, sound_id uuid references original_sounds,
  reason text not null check (reason in ('copyright','offensive','other')), details text,
  status text not null default 'open' check (status in ('open','reviewing','actioned','dismissed')),
  resolved_by uuid references profiles, created_at timestamptz not null default now(), resolved_at timestamptz);

create table if not exists music_api_log (          -- error monitoring for the admin dashboard
  id bigserial primary key, fn text not null, status int, message text, request_id text, created_at timestamptz not null default now());

alter table posts   add column if not exists music_track_id uuid references music_tracks, add column if not exists music_sound_id uuid references original_sounds, add column if not exists music_start int default 0, add column if not exists is_video boolean default false, add column if not exists video_fit boolean default false;
alter table reels   add column if not exists music_track_id uuid references music_tracks, add column if not exists music_sound_id uuid references original_sounds, add column if not exists music_start int default 0, add column if not exists music_vol numeric default 1, add column if not exists video_vol numeric default 1;
alter table stories add column if not exists music_track_id uuid references music_tracks, add column if not exists music_sound_id uuid references original_sounds, add column if not exists music_start int default 0;

-- RLS
alter table music_licenses enable row level security; alter table music_artists enable row level security; alter table music_albums enable row level security;
alter table music_genres enable row level security; alter table music_tracks enable row level security; alter table music_favorites enable row level security;
alter table music_usage enable row level security; alter table original_sounds enable row level security; alter table music_reports enable row level security; alter table music_api_log enable row level security;

create policy "lic read" on music_licenses for select using (is_verified());
create policy "lic staff" on music_licenses for all using (is_staff()) with check (is_staff());
create policy "art read" on music_artists for select using (is_verified());
create policy "alb read" on music_albums for select using (is_verified());
create policy "gen read" on music_genres for select using (is_verified());
-- Catalogue writes happen only with the service role (rf-music / rf-sync functions); staff may restrict tracks.
create policy "trk read" on music_tracks for select using (is_verified() and (status = 'active' or is_staff()));
create policy "trk staff update" on music_tracks for update using (is_staff()) with check (is_staff());
create policy "fav own" on music_favorites for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "use insert own" on music_usage for insert with check (user_id = auth.uid());
create policy "use staff read" on music_usage for select using (is_staff() or user_id = auth.uid());
create policy "snd read" on original_sounds for select using (is_verified() and (status = 'approved' or owner_id = auth.uid() or is_staff()));
create policy "snd insert own" on original_sounds for insert with check (owner_id = auth.uid() and status = 'pending');
create policy "snd owner delete" on original_sounds for delete using (owner_id = auth.uid());
create policy "snd staff" on original_sounds for update using (is_staff()) with check (is_staff());
create policy "rep insert" on music_reports for insert with check (reporter_id = auth.uid());
create policy "rep staff" on music_reports for all using (is_staff()) with check (is_staff());
create policy "log staff" on music_api_log for select using (is_staff());

-- A track may be attached to content only if it is active AND its licence is confirmed for user-generated content, unexpired.
create or replace function track_attachable(tid uuid) returns boolean language sql stable security definer set search_path=public as $$
  select exists (select 1 from music_tracks t join music_licenses l on l.id = t.license_id
    where t.id = tid and t.status = 'active' and l.allow_ugc_attach and (l.expires_at is null or l.expires_at > now()))
$$;

-- Private bucket for original sounds; owners upload into their own folder, 10 MB cap enforced by the table check + bucket limit.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('original-sounds','original-sounds',false,10485760,array['audio/mpeg','audio/mp4','audio/aac','audio/wav','audio/ogg']) on conflict do nothing;
create policy "sounds upload own" on storage.objects for insert to authenticated with check (bucket_id='original-sounds' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "sounds read own or staff" on storage.objects for select to authenticated using (bucket_id='original-sounds' and ((storage.foldername(name))[1] = auth.uid()::text or is_staff()));

-- "Trending" = most used on GITAMGRAM in the last 30 days (the provider exposes no popularity data).
create or replace function music_trending(n int default 20) returns table (track_id uuid, uses bigint)
language sql stable security definer set search_path=public as $$
  select u.track_id, count(*) from music_usage u join music_tracks t on t.id = u.track_id
  where u.track_id is not null and u.created_at > now() - interval '30 days' and t.status = 'active'
  group by u.track_id order by count(*) desc limit n
$$;
