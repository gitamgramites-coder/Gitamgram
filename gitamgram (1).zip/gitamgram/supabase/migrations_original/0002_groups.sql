-- Groups & communities (public/private). Members-only content for private spaces.
create type group_kind as enum ('group','community');
create type group_privacy as enum ('public','private');

create table groups (
  id uuid primary key default gen_random_uuid(),
  kind group_kind not null default 'group', privacy group_privacy not null default 'public',
  name text not null check (char_length(name) between 2 and 50), description text default '',
  campus_id uuid references campuses, -- null = all campuses
  owner_id uuid references profiles not null, created_at timestamptz default now()
);
create table group_members (group_id uuid references groups on delete cascade, user_id uuid references profiles on delete cascade, role text default 'member' check (role in ('owner','member')), primary key (group_id,user_id));
create table group_join_requests (group_id uuid references groups on delete cascade, user_id uuid references profiles on delete cascade, created_at timestamptz default now(), primary key (group_id,user_id));
create table group_messages (id uuid primary key default gen_random_uuid(), group_id uuid references groups on delete cascade not null, sender_id uuid references profiles not null, body text not null check (char_length(body)<=2000), created_at timestamptz default now());
create table group_posts (id uuid primary key default gen_random_uuid(), group_id uuid references groups on delete cascade not null, author_id uuid references profiles not null, body text not null check (char_length(body)<=500), created_at timestamptz default now());

create or replace function in_group(g uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from group_members where group_id=g and user_id=auth.uid()) $$;
create or replace function owns_group(g uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from groups where id=g and owner_id=auth.uid()) $$;
create or replace function group_is_public(g uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists (select 1 from groups where id=g and privacy='public') $$;

alter table groups enable row level security; alter table group_members enable row level security; alter table group_join_requests enable row level security;
alter table group_messages enable row level security; alter table group_posts enable row level security;

-- Names/descriptions are discoverable by verified users; everything inside is gated.
create policy "groups discover" on groups for select using (is_verified());
create policy "groups create" on groups for insert with check (owner_id=auth.uid() and is_verified());
create policy "groups owner edit" on groups for update using (owner_id=auth.uid());
create policy "groups owner delete" on groups for delete using (owner_id=auth.uid() or is_staff());

create policy "members read" on group_members for select using (in_group(group_id) or group_is_public(group_id));
create policy "join public / owner adds" on group_members for insert with check (
  (user_id=auth.uid() and group_is_public(group_id) and is_verified()) or owns_group(group_id) or (user_id=auth.uid() and role='owner' and owns_group(group_id)));
create policy "leave or owner removes" on group_members for delete using (user_id=auth.uid() or owns_group(group_id));

create policy "requests own/owner read" on group_join_requests for select using (user_id=auth.uid() or owns_group(group_id));
create policy "request private" on group_join_requests for insert with check (user_id=auth.uid() and is_verified());
create policy "request resolve" on group_join_requests for delete using (user_id=auth.uid() or owns_group(group_id));

create policy "gmsg members" on group_messages for select using (in_group(group_id));
create policy "gmsg send" on group_messages for insert with check (sender_id=auth.uid() and in_group(group_id));
create policy "gpost read" on group_posts for select using (in_group(group_id) or group_is_public(group_id));
create policy "gpost write" on group_posts for insert with check (author_id=auth.uid() and in_group(group_id));
create policy "gpost delete" on group_posts for delete using (author_id=auth.uid() or owns_group(group_id) or is_staff());
create index on group_messages (group_id, created_at);
create index on group_posts (group_id, created_at desc);
